// frontend/app.js
const API_BASE_URL = 'http://localhost:3001/api'; // Backend URL

// --- State Management (Session Storage) ---
function setState(key, value) { try { sessionStorage.setItem(key, JSON.stringify(value)); } catch (e) { console.error("Error saving state:", e); } }
function getState(key) { try { const item = sessionStorage.getItem(key); return item ? JSON.parse(item) : null; } catch (e) { console.error("Error reading state:", e); return null; } }
function removeState(key) { sessionStorage.removeItem(key); }

// --- UI Helpers ---
function showSpinner(show = true, id = 'spinner') { const spinner = document.getElementById(id); if (spinner) spinner.style.display = show ? 'block' : 'none'; }
function showPartySpinner(show = true) { showSpinner(show, 'partyspinner'); }
function setMessage(elementId, text, type = 'error') {
    const msgElement = document.getElementById(elementId);
    if (!msgElement) return;
    msgElement.textContent = text;
    msgElement.className = `message ${type}`; // error, success, info
}
function disableButton(buttonId, disable = true) { const btn = document.getElementById(buttonId); if (btn) btn.disabled = disable; }

// --- API Call Wrapper ---
async function apiCall(endpoint, method = 'GET', body = null, requiresAuth = false) {
    const url = `${API_BASE_URL}${endpoint}`;
    const options = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) options.body = JSON.stringify(body);
    if (requiresAuth) {
        const token = getAdminToken();
        if (!token) { throw new Error('AUTH_REQUIRED'); }
        options.headers['Authorization'] = `Bearer ${token}`;
    }
    try {
        const response = await fetch(url, options);
        const data = await response.json();
        if (!response.ok) { const error = new Error(data.error || `Request failed: ${response.status}`); error.status = response.status; error.data = data; throw error; }
        return data;
    } catch (error) { console.error(`API Error (${method} ${endpoint}):`, error); throw error; }
}

// --- Voter Flow ---
async function checkAadhaar() {
    const aadhaarInput = document.getElementById('aadhaarInput'); const msgEl = document.getElementById('authMessage'); const btnId = 'verifyBtn';
    if (!/^\d{12}$/.test(aadhaarInput.value)) { setMessage(msgEl.id, 'Please enter 12 digits.', 'error'); return; }
    setMessage(msgEl.id, '', ''); disableButton(btnId, true); showSpinner(true);
    try {
        const data = await apiCall('/voter/check-aadhaar', 'POST', { aadhaar: aadhaarInput.value });
        setState('voterSessionId', data.sessionId); setState('voterAadhaar', aadhaarInput.value);
        setMessage(msgEl.id, 'Verified. Redirecting...', 'success'); setTimeout(() => window.location.href = 'voter_otp.html', 1000);
    } catch (error) { setMessage(msgEl.id, error.message || 'Verification failed.', 'error'); disableButton(btnId, false); } finally { showSpinner(false); }
}
async function requestProfileAndOtp() {
    const sessionId = getState('voterSessionId'); const profileDiv = document.getElementById('profileInfo'); const msgEl = document.getElementById('otpMessage');
    if (!sessionId) { setMessage(msgEl.id, 'Session error.', 'error'); profileDiv.innerHTML = '<p class="error">Invalid session.</p>'; return; }
    setMessage(msgEl.id, 'Requesting profile & OTP...', 'info'); showSpinner(true);
    try {
        const data = await apiCall('/voter/request-profile-otp', 'POST', { sessionId });
        profileDiv.innerHTML = `<p><strong>Name:</strong> ${data.profile.name}</p><p><strong>Mobile:</strong> ${data.profile.mobileMasked}</p><p><strong>Email:</strong> ${data.profile.emailMasked}</p>`;
        setMessage(msgEl.id, 'OTP sent. Check mobile/email.', 'success');
    } catch (error) { setMessage(msgEl.id, error.message || 'Failed.', 'error'); profileDiv.innerHTML = '<p class="error">Failed load profile.</p>'; } finally { showSpinner(false); }
}
async function verifyVoterOtp() {
    const sessionId = getState('voterSessionId'); const otp = document.getElementById('otpInput').value; const msgEl = document.getElementById('otpMessage'); const btnId = 'verifyOtpBtn';
    if (!sessionId) { setMessage(msgEl.id, 'Session error.', 'error'); return; } if (!otp || otp.length !== 6) { setMessage(msgEl.id, 'Enter 6-digit OTP.', 'error'); return; }
    setMessage(msgEl.id, '', ''); disableButton(btnId, true); showSpinner(true);
    try {
        await apiCall('/voter/verify-otp', 'POST', { sessionId, otp });
        setMessage(msgEl.id, 'Verified. Redirecting...', 'success'); setTimeout(() => window.location.href = 'voter_vote.html', 1000);
    } catch (error) { setMessage(msgEl.id, error.message || 'OTP Invalid.', 'error'); disableButton(btnId, false); } finally { showSpinner(false); }
}
async function fetchPartiesAndPopulate() {
    const listDiv = document.getElementById('partyList'); const msgEl = document.getElementById('voteMessage'); const btn = document.getElementById('castVoteBtn');
    setMessage(msgEl.id, '', ''); showPartySpinner(true); if (!getState('voterSessionId')) { setMessage(msgEl.id, 'Invalid session.', 'error'); listDiv.innerHTML = '<p class="error">Session invalid.</p>'; showPartySpinner(false); return; }
    try {
        const parties = await apiCall('/parties'); listDiv.innerHTML = '';
        if (parties && parties.length > 0) {
            parties.forEach(p => {
                listDiv.innerHTML += `<label><input type="radio" name="party" value="${p.id}" required onchange="document.getElementById('castVoteBtn').disabled=false;"><span> ${p.abbreviation} (${p.name})</span></label>`;
            }); btn.disabled = true;
        } else { listDiv.innerHTML = '<p class="error">No parties available.</p>'; }
    } catch (error) { setMessage(msgEl.id, error.message || 'Failed load parties.', 'error'); listDiv.innerHTML = '<p class="error">Error loading options.</p>'; } finally { showPartySpinner(false); }
}
async function requestBlockchainKey() {
    const sessionId = getState('voterSessionId'); const radio = document.querySelector('input[name="party"]:checked'); const msgEl = document.getElementById('voteMessage'); const btnId = 'castVoteBtn';
    if (!sessionId) { setMessage(msgEl.id, 'Session error.', 'error'); return; } if (!radio) { setMessage(msgEl.id, 'Select a party.', 'error'); return; }
    setState('selectedPartyId', radio.value); setState('selectedPartyName', radio.nextElementSibling.textContent.trim());
    setMessage(msgEl.id, '', ''); disableButton(btnId, true); showSpinner(true);
    try {
        await apiCall('/voter/request-blockchain-key', 'POST', { sessionId });
        setMessage(msgEl.id, 'Key sent. Redirecting...', 'success'); setTimeout(() => window.location.href = 'voter_confirm.html', 1000);
    } catch (error) { setMessage(msgEl.id, error.message || 'Key request failed.', 'error'); disableButton(btnId, false); } finally { showSpinner(false); }
}
function displaySelectedParty() { const name = getState('selectedPartyName'); const el = document.getElementById('selectedPartyDisplay'); if (el && name) el.textContent = name; else if (el) el.textContent = 'Error'; }
async function submitVote() {
    const sessionId = getState('voterSessionId'); const partyId = getState('selectedPartyId'); const key = document.getElementById('blockchainKeyInput').value; const msgEl = document.getElementById('confirmMessage'); const btnId = 'voteNowBtn';
    if (!sessionId || !partyId) { setMessage(msgEl.id, 'Session/Party error.', 'error'); return; } if (!key) { setMessage(msgEl.id, 'Enter Blockchain Key.', 'error'); return; }
    setMessage(msgEl.id, '', ''); disableButton(btnId, true); showSpinner(true);
    try {
        const data = await apiCall('/voter/cast-vote', 'POST', { sessionId, partyId, blockchainKey: key });
        setState('finalBallotId', data.ballotId); setMessage(msgEl.id, 'Vote submitted! Redirecting...', 'success');
        removeState('voterSessionId'); removeState('selectedPartyId'); removeState('selectedPartyName'); removeState('voterAadhaar');
        setTimeout(() => window.location.href = 'voter_success.html', 1000);
    } catch (error) { if (error.status === 403) { setMessage(msgEl.id, error.message || 'Already voted.', 'error'); removeState('voterSessionId'); } else { setMessage(msgEl.id, error.message || 'Vote failed.', 'error'); } disableButton(btnId, false); } finally { showSpinner(false); }
}
function displayBallotId() { const id = getState('finalBallotId'); const el = document.getElementById('ballotIdDisplay'); if (el && id) el.textContent = id; else if (el) el.textContent = 'Error'; }

// --- Admin Flow ---
function saveAdminToken(token) { localStorage.setItem('adminAuthToken', token); }
function getAdminToken() { return localStorage.getItem('adminAuthToken'); }
function removeAdminToken() { localStorage.removeItem('adminAuthToken'); }
function saveAdminUsername(username) { localStorage.setItem('adminUsername', username); }
function getAdminUsername() { return localStorage.getItem('adminUsername'); }
function removeAdminUsername() { localStorage.removeItem('adminUsername'); }

async function adminLogin() {
    const u = document.getElementById('adminUsername').value; const p = document.getElementById('adminPassword').value; const msgEl = document.getElementById('adminLoginMessage'); const btnId = 'adminLoginBtn';
    if (!u || !p) { setMessage(msgEl.id, 'Username/Password required.', 'error'); return; }
    setMessage(msgEl.id, '', ''); disableButton(btnId, true); showSpinner(true);
    try {
        await apiCall('/admin/login', 'POST', { username: u, password: p });
        saveAdminUsername(u); setMessage(msgEl.id, 'Login ok. Redirecting...', 'success'); setTimeout(() => window.location.href = 'admin_otp.html', 1000);
    } catch (error) { setMessage(msgEl.id, error.message || 'Admin login failed.', 'error'); disableButton(btnId, false); } finally { showSpinner(false); }
}
async function adminVerifyOtp() {
    const u = getAdminUsername(); const otp = document.getElementById('adminOtpInput').value; const msgEl = document.getElementById('adminOtpMessage'); const btnId = 'adminVerifyBtn';
    if (!u) { setMessage(msgEl.id, 'Username error.', 'error'); return; } if (!otp || otp.length !== 6) { setMessage(msgEl.id, 'Enter 6-digit OTP.', 'error'); return; }
    setMessage(msgEl.id, '', ''); disableButton(btnId, true); showSpinner(true);
    try {
        const data = await apiCall('/admin/verify-otp', 'POST', { username: u, otp: otp });
        saveAdminToken(data.token); setMessage(msgEl.id, 'Verified. Redirecting...', 'success'); setTimeout(() => window.location.href = 'admin_dashboard.html', 1000);
    } catch (error) { setMessage(msgEl.id, error.message || 'Admin OTP Invalid.', 'error'); disableButton(btnId, false); } finally { showSpinner(false); }
}
function checkAdminLoginStatus() {
    const token = getAdminToken(); if (!token) { window.location.href = 'admin_login.html'; return; }
    const u = getAdminUsername(); const el = document.getElementById('welcomeAdmin'); if (el && u) el.textContent = `Welcome, ${u}!`;
}
async function fetchResults() {
    const tbody = document.getElementById('resultsTableBody'); const totalEl = document.getElementById('totalVotes'); const msgEl = document.getElementById('resultsMessage');
    setMessage(msgEl.id, '', ''); showSpinner(true); tbody.innerHTML = '<tr><td colspan="4">Loading...</td></tr>';
    try {
        const data = await apiCall('/admin/results', 'GET', null, true); tbody.innerHTML = '';
        if (data.results && data.results.length > 0) { data.results.forEach(p => { tbody.innerHTML += `<tr><td>${p.id}</td><td>${p.name}</td><td>${p.abbreviation}</td><td>${p.votes}</td></tr>`; }); }
        else { tbody.innerHTML = '<tr><td colspan="4">No results yet.</td></tr>'; }
        totalEl.textContent = data.totalVotes || 0; setMessage(msgEl.id, 'Results updated.', 'success'); setTimeout(() => setMessage(msgEl.id, '', ''), 3000);
    } catch (error) { if (error.message === 'AUTH_REQUIRED') { setMessage(msgEl.id, 'Auth failed. Login again.', 'error'); removeAdminToken(); removeAdminUsername(); setTimeout(() => window.location.href = 'admin_login.html', 1500); } else { setMessage(msgEl.id, error.message || 'Failed fetch results.', 'error'); tbody.innerHTML = '<tr><td colspan="4">Error loading.</td></tr>'; } } finally { showSpinner(false); }
}
async function adminLogout() { const token = getAdminToken(); removeAdminToken(); removeAdminUsername(); try { if (token) await apiCall('/admin/logout', 'POST', null, true); } catch (e) { console.error("Logout API call failed:", e); } finally { window.location.href = 'index.html'; } }