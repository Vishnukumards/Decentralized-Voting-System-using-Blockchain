// backend/server.js
// ==================

// --- Core Dependencies ---
const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// --- Blockchain Dependencies ---
const { Web3 } = require('web3');

// --- OTP Service Dependencies ---
require('dotenv').config(); // Load environment variables (.env file) FIRST
const nodemailer = require('nodemailer');
const twilio = require('twilio');

// --- Express App Setup ---
const app = express();
const port = process.env.PORT || 3001; // Allow port override via environment variable

app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // Enable parsing JSON request bodies

// --- Configuration ---
const GANACHE_RPC_URL = process.env.GANACHE_RPC_URL || 'http://127.0.0.1:7545';
// !!! CRITICAL: Replace with your LATEST deployed contract address !!!
const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS || '0x77A634c377e9D732ED0a313966B2DF9840E6D3F6'; // Example, use yours!
// Secret Salt for hashing voter IDs - Should be unique per election & kept secret
const ELECTION_SALT = process.env.ELECTION_SALT || "CHANGE_THIS_IN_DOT_ENV_TO_A_RANDOM_SECRET_STRING";

// --- Global Variables ---
let web3;
let votingContract;
let backendAccount;
let votingContractABI;

// --- In-Memory Stores (Replace with a Database in Production) ---
const otpStore = {};           // Stores { identifier: { otp, expires, type } }
const blockchainKeyStore = {}; // Stores { sessionId: { key, expires } }
const activeVoterSessions = {};// Stores { sessionId: { aadhaar, stage } }
const activeAdminSessions = {};// Stores { token: { username, loggedInAt } }

// --- Simulated Databases (Replace with actual DB queries in Production) ---
// ENSURE CONSISTENT PHONE FORMAT (E.164 recommended: +CountryCodeNumber)
const VOTE_ELIGIBILITY_DB = {
    '878801102298': { name: 'Vishnu Kumar D S', dob: '31/03/2003', mobile: '+919902468983', email: 'vishnukumardsvishnu@gmail.com', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043', aadhaar: '878801102298' },
    '517782263844': { name: 'Darshan KV', dob: '16/06/2003', mobile: '+917204232086', email: 'darshankvdarshankv59@gmail.com', aadhaar: '517782263844', address: 'hennur cross, 560043, Bengaluru.' },
    '266017783020': { name: 'Vikas S', dob: '10/03/2003', mobile: '+919742390432', email: 'vikassvikasvijay@gmail.com', aadhaar: '266017783020', address: '#2 VB Hemavathi building Suvarna Nagar Doda bidru kallu Nagsandra Post 560073 Bengaluru.' },
    '878801182298': { name: 'Soma Shekar', dob: '31/03/2003', mobile: '+919036634209', email: 'somutakur5926@gmail.com', aadhaar: '878801182298', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043'},
    '989812345678': { name: 'Rahul navi', dob: '22/11/2002', mobile: '+918088122635', email: 'rahulnavi92@gmail.com', address: '23, Indiranagar, Bengaluru 560038', aadhaar: '989812345678' },
    '894567231901': { name: 'Kaushik K H', dob: '05/05/2001', mobile: '+919740453872', email: 'kaushikkh1431@gmail.com', address: 'Flat 302, MG Residency, BTM Layout, Bengaluru 560076', aadhaar: '894567231901' },
    '776543213456': { name: 'Vinay ', dob: '18/09/2000', mobile: '+917625071517', email: 'vinaynaikcr7@gmail.com', address: '12, Jayanagar 4th Block, Bengaluru 560011', aadhaar: '776543213456' },
    '556789009876': { name: 'Kumar', dob: '15/08/2002', mobile: '+919392433367', email: 'mekelakumarreddy@gmail.com', address: 'A-16, KR Puram, Bengaluru 560036', aadhaar: '556789009876' },
    '449988776655': { name: 'Anil', dob: '09/01/2001', mobile: '+919980146855', email: 'anilkumarn6855@mail.com', address: 'B-42, Whitefield Main Road, Bengaluru 560066', aadhaar: '449988776655' },
    '332211009988': { name: 'Kammar Rao', dob: '03/03/2000', mobile: '+917022800262', email: 'kiranrao93@gmail.com', address: '14, JP Nagar Phase 6, Bengaluru 560078', aadhaar: '332211009988' },
    '221199887766': { name: 'Meghana K', dob: '12/07/2003', mobile: '+919495969789', email: 'meghana.k@gmail.com', address: 'No. 5, Marathahalli ORR, Bengaluru 560037', aadhaar: '221199887766' },
    '511783078456': { name: 'Rakshitha', dob: '12/07/2003', mobile: '+919380930316', email: 'rakshitharacchu185@gmail.com', address: 'VVIT Hostel', aadhaar: '511783078456' },
    '511783078467':{ name: 'Nisarga', dob: '12/07/2003', mobile: '+918431737209', email: 'nisarganisarga322@gmail.com', address: 'VVIT Hostel', aadhaar: '511783078456' }
};
// !!! SECURITY WARNING: Admin password stored in plain text. Use hashing (e.g., bcrypt) in production !!!
const ADMIN_DB = {
    'vishnu123': { password: '@Vishnu89', name: 'Vishnu Reddy', dob: '02/28/2003', email: 'gowthamg78657g@gmail.com', number: '+919902468983' }
};


// --- Helper Functions ---

/** Generates a random OTP of specified length */
function generateOtp(length = 6) {
    return crypto.randomInt(10**(length - 1), 10**length).toString();
}

/** Generates a secure random token */
function generateToken(length = 32) {
    return crypto.randomBytes(length).toString('hex');
}

/** Generates a unique, anonymous hash for a voter based on Aadhaar and a secret salt */
function generateVoterIdentifierHash(aadhaar) {
    if (!ELECTION_SALT || ELECTION_SALT === "DEFAULT_FALLBACK_SALT_NEEDS_REPLACING") {
         console.warn("!!! SECURITY WARNING: Using default or missing ELECTION_SALT. Please set a unique secret ELECTION_SALT in your .env file!");
    }
    const hash = crypto.createHash('sha256').update(aadhaar + ELECTION_SALT).digest('hex');
    return '0x' + hash;
}

/** Middleware to verify admin authentication token */
function verifyAdminToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Expect "Bearer <token>"

    if (!token) {
        return res.status(401).json({ error: 'Unauthorized: No token provided.' });
    }

    const session = activeAdminSessions[token];
    // Add expiry check to session in a real application
    if (!session) {
        return res.status(401).json({ error: 'Unauthorized: Invalid or expired token.' });
    }

    req.adminUsername = session.username; // Attach username to request object
    next(); // Proceed to the protected route
}

// --- OTP Service Setup ---

// Configure Nodemailer (Email)
const transporter = nodemailer.createTransport({
    service: 'gmail', // Or configure for another provider
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS, // MUST be App Password for Gmail if 2FA is enabled
    },
});

// Configure Twilio (SMS) - Check if credentials exist
let twilioClient;
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
    try {
        twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        console.log("[Twilio] Client initialized successfully.");
    } catch (err) {
        console.error("[Twilio] ERROR: Failed to initialize Twilio client. Check credentials.", err.message);
        twilioClient = null; // Ensure client is null if initialization fails
    }
} else {
    console.warn("[Twilio] WARNING: Twilio Account SID or Auth Token missing in .env. SMS sending will be disabled.");
    twilioClient = null;
}

// --- OTP Sending Functions ---

/** Sends OTP via Email */
async function sendEmailOTP(email, otp, subject = 'Your Voting App OTP', bodyPrefix = 'Your OTP is:') {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
        console.error("[EMAIL ERROR] Cannot send email. EMAIL_USER or EMAIL_PASS missing in .env");
        return false;
    }
    if (!email) {
         console.error("[EMAIL ERROR] Cannot send email. Recipient email address is missing.");
         return false;
    }

    const mailOptions = {
        from: `"Decentralized Voting System" <${process.env.EMAIL_USER}>`,
        to: email,
        subject: subject,
        text: `${bodyPrefix} ${otp}\nThis code is valid for 5 minutes.`,
        html: `<p>${bodyPrefix} <b>${otp}</b></p><p>This code is valid for 5 minutes.</p>`,
    };

    try {
        let info = await transporter.sendMail(mailOptions);
        console.log(`[EMAIL] OTP/Key sent successfully to ${email}. Message ID: ${info.messageId}`);
        return true;
    } catch (error) {
        console.error(`[EMAIL ERROR] Failed to send OTP/Key to ${email}:`, error.message || error);
        return false;
    }
}

/** Sends OTP via SMS using Twilio */
async function sendSMSOTP(phoneNumber, otp, bodyPrefix = 'Your Voting App OTP is:') {
    // Check if Twilio is configured and recipient number is provided
    if (!twilioClient || !process.env.TWILIO_PHONE_NUMBER) {
        console.warn(`[SMS WARN] Cannot send SMS to ${phoneNumber}. Twilio client not initialized or TWILIO_PHONE_NUMBER missing in .env.`);
        return false;
    }
    if (!phoneNumber) {
        console.warn(`[SMS WARN] Cannot send SMS. Recipient phone number is missing.`);
        return false;
    }

    // Ensure E.164 format (e.g., +91xxxxxxxxxx)
    let formattedPhoneNumber = phoneNumber.trim();
    if (!formattedPhoneNumber.startsWith('+')) {
        if (formattedPhoneNumber.length === 10) { // Basic check for 10-digit Indian numbers
            formattedPhoneNumber = `+91${formattedPhoneNumber}`;
        } else {
            console.error(`[SMS ERROR] Invalid phone number format for Twilio: ${phoneNumber}. Requires E.164 format (e.g., +91...).`);
            return false;
        }
    }

    try {
        console.log(`[SMS] Attempting to send OTP/Key to ${formattedPhoneNumber} from ${process.env.TWILIO_PHONE_NUMBER}`);
        const message = await twilioClient.messages.create({
            body: `${bodyPrefix} ${otp}. Valid for 5 mins.`,
            from: process.env.TWILIO_PHONE_NUMBER, // Your Twilio Number (Sender)
            to: formattedPhoneNumber,           // Recipient Number
        });
        console.log(`[SMS] OTP/Key sent successfully to ${formattedPhoneNumber}. SID: ${message.sid}`);
        return true;
    } catch (error) {
        console.error(`[SMS ERROR] Failed to send OTP/Key to ${formattedPhoneNumber}:`, error.message || error);
        if (error.code) {
            console.error(`  Twilio Error Code: ${error.code}`);
            console.error(`  More Info: ${error.moreInfo || 'N/A'}`);
            if (error.code === 21608) {
                console.error("  >>>>> FIX: This recipient number must be verified in your Twilio Trial account dashboard! <<<<<");
                console.error("  >>>>> OR: Upgrade your Twilio account. <<<<<");
            } else if (error.code === 21211) {
                console.error("  >>>>> CHECK: The recipient phone number format might be invalid for Twilio. <<<<<");
            } else if (error.code === 21408) {
                console.error("  >>>>> CHECK: Your Twilio account might lack permission to send to this region/number. <<<<<");
            } else if (error.code === 21610) {
                 console.error("  >>>>> CHECK: Attempting to send from a blacklisted number (often happens with trial numbers if flagged). <<<<<");
            }
        }
        return false;
    }
}

// --- Initialization Functions ---

/** Loads the contract ABI from the JSON file */
function loadContractABI() {
    try {
        const abiPath = path.resolve(__dirname, '../build/contracts/VotingContract.json');
        if (!fs.existsSync(abiPath)) {
            throw new Error(`ABI file not found at ${abiPath}. Did you run 'truffle compile'?`);
        }
        const contractJson = JSON.parse(fs.readFileSync(abiPath, 'utf8'));
        votingContractABI = contractJson.abi;
        console.log("[Init] Successfully loaded Contract ABI.");
    } catch (err) {
        console.error("!!! FATAL ERROR: Could not load contract ABI from build file.", err.message || err);
        console.error("!!! Ensure you have run 'truffle compile' and 'truffle migrate' successfully in the parent directory.");
        process.exit(1); // Critical error, exit
    }
}

/** Initializes Web3 connection and Contract instance */
function initializeWeb3AndContract() {
    try {
        // Basic validation of contract address format
        if (!CONTRACT_ADDRESS || !CONTRACT_ADDRESS.startsWith('0x') || CONTRACT_ADDRESS.length !== 42) {
            throw new Error(`Invalid CONTRACT_ADDRESS: "${CONTRACT_ADDRESS}". Please check .env or the constant in server.js. It must be a 42-character hex string starting with 0x.`);
        }

        web3 = new Web3(GANACHE_RPC_URL);
        votingContract = new web3.eth.Contract(votingContractABI, CONTRACT_ADDRESS);
        console.log(`[Init] Web3 connected to ${GANACHE_RPC_URL}`);
        console.log(`[Init] Contract object created for address: ${CONTRACT_ADDRESS}`);

    } catch (err) {
        console.error("!!! FATAL ERROR initializing Web3 or Contract object:", err.message || err);
        console.error("!!! Ensure Ganache (or your RPC provider) is running at", GANACHE_RPC_URL);
        console.error("!!! Verify CONTRACT_ADDRESS is correct and ABI loaded successfully.");
        process.exit(1); // Critical error, exit
    }
}

/** Sets up the backend's primary Ethereum account for sending transactions */
async function setupBackendAccount() {
    // Prevent re-running if already set up
    if (backendAccount) return;

    try {
        if (!web3) {
            throw new Error("Web3 provider not initialized before setting up account.");
        }
        const accounts = await web3.eth.getAccounts();
        if (!accounts || accounts.length === 0) {
            throw new Error("No accounts found from RPC provider. Ensure Ganache is running and has accounts, or your RPC connection is valid.");
        }
        backendAccount = accounts[0]; // Use the first available account
        console.log(`[Init] Backend configured to use account: ${backendAccount}`);

        // Check balance
        const balanceWei = await web3.eth.getBalance(backendAccount);
        const balanceEth = web3.utils.fromWei(balanceWei, 'ether');
        console.log(`[Init] Backend account balance: ${balanceEth} ETH`);
        if (parseFloat(balanceEth) < 0.01) { // Lowered warning threshold
            console.warn(`!!! WARNING: Backend account ${backendAccount} has very low balance (${balanceEth} ETH). Transactions might fail due to insufficient gas.`);
        }
    } catch (error) {
        console.error("!!! FATAL ERROR setting up backend Ethereum account:", error.message || error);
        process.exit(1); // Critical error, exit
    }
}


// --- API Endpoints ---

app.get('/api/ping', (req, res) => {
    res.json({
         message: 'Backend Pong!',
         timestamp: new Date().toISOString(),
         contractAddress: CONTRACT_ADDRESS,
         rpcUrl: GANACHE_RPC_URL
        });
});

// === Voter Flow ===

app.post('/api/voter/check-aadhaar', (req, res) => {
    const { aadhaar } = req.body;
    if (!aadhaar || !/^\d{12}$/.test(aadhaar)) {
        return res.status(400).json({ error: 'Invalid Aadhaar format (must be 12 digits).' });
    }

    const voterData = VOTE_ELIGIBILITY_DB[aadhaar];
    if (voterData) {
        const sessionId = generateToken(16);
        activeVoterSessions[sessionId] = { aadhaar: aadhaar, stage: 'aadhaar_verified' };
        console.log(`[AUTH] Aadhaar ${aadhaar} verified. Session created: ${sessionId}`);
        res.json({ success: true, sessionId: sessionId });
    } else {
        console.log(`[AUTH] Aadhaar ${aadhaar} not found in eligible list.`);
        // Use 403 Forbidden instead of 404 maybe? Or 400 Bad Request if not found is expected invalid input.
        res.status(404).json({ error: 'Aadhaar number not found in eligible voter list.' });
    }
});

app.post('/api/voter/request-profile-otp', async (req, res) => {
    const { sessionId } = req.body;
    const session = activeVoterSessions[sessionId];

    if (!session || session.stage !== 'aadhaar_verified') {
        return res.status(400).json({ error: 'Invalid session or request sequence.' });
    }

    const voterData = VOTE_ELIGIBILITY_DB[session.aadhaar];
    if (!voterData || !voterData.mobile || !voterData.email) {
        console.error(`[OTP ERROR] Missing mobile ('${voterData?.mobile}') or email ('${voterData?.email}') for Aadhaar ${session.aadhaar}. Cannot send OTP.`);
        return res.status(500).json({ error: 'Internal error: Voter contact information missing or incomplete.' });
    }

    const otp = generateOtp();
    const expiry = Date.now() + 5 * 60 * 1000; // 5 minutes
    otpStore[session.aadhaar] = { otp: otp, expires: expiry, type: 'voter' };
    console.log(`[OTP] Generated Profile OTP for ${session.aadhaar}: ${otp}`);

    // Send OTP async
    let emailSuccess = false;
    let smsSuccess = false;
    try {
        emailSuccess = await sendEmailOTP(voterData.email, otp, 'Your Voter Profile OTP', 'Your profile verification OTP is:');
        smsSuccess = await sendSMSOTP(voterData.mobile, otp, 'Your Voter Profile OTP is:');

        if (!emailSuccess && !smsSuccess) {
            console.error(`[OTP FAIL] CRITICAL: Failed to send Profile OTP via BOTH Email and SMS for Aadhaar ${session.aadhaar}.`);
            delete otpStore[session.aadhaar]; // Clean up failed attempt
            return res.status(503).json({ error: 'Service unavailable: Failed to send OTP. Please try again later.' });
        }

        if (!emailSuccess) console.warn(`[OTP WARN] Failed to send Profile OTP email to ${voterData.email}.`);
        if (!smsSuccess) console.warn(`[OTP WARN] Failed to send Profile OTP SMS to ${voterData.mobile}. (Check Twilio config/trial limits/verified numbers).`);

        session.stage = 'otp_sent';
        res.json({
            success: true,
            message: `OTP sent successfully ${emailSuccess ? 'to email' : ''}${emailSuccess && smsSuccess ? ' and ' : ''}${smsSuccess ? 'to mobile' : ''}.`,
            profile: { // Send masked profile data back
                name: voterData.name,
                dob: voterData.dob,
                address: voterData.address, // Consider if sending full address is needed here
                mobileMasked: voterData.mobile ? '*******' + voterData.mobile.slice(-3) : 'N/A',
                emailMasked: voterData.email ? voterData.email.split('@')[0].slice(0, 2) + '***@' + voterData.email.split('@')[1] : 'N/A'
            }
        });

    } catch (error) {
        console.error(`[OTP ERROR] Unexpected error during Profile OTP sending process for Aadhaar ${session.aadhaar}:`, error);
        delete otpStore[session.aadhaar]; // Clean up potentially stored OTP
        res.status(500).json({ error: 'An unexpected server error occurred while sending the OTP.' });
    }
});

app.post('/api/voter/verify-otp', (req, res) => {
    const { sessionId, otp } = req.body;
    if (!sessionId || !otp) {
        return res.status(400).json({ error: 'Missing sessionId or otp in request.' });
    }

    const session = activeVoterSessions[sessionId];
    if (!session || session.stage !== 'otp_sent') {
        return res.status(400).json({ error: 'Invalid session or request sequence (expecting OTP verification).' });
    }

    const aadhaar = session.aadhaar;
    const storedOtpData = otpStore[aadhaar];

    if (!storedOtpData || storedOtpData.type !== 'voter') {
        return res.status(400).json({ error: 'OTP not found or invalid type. Please request OTP again.' });
    }
    if (storedOtpData.expires < Date.now()) {
        delete otpStore[aadhaar];
        return res.status(400).json({ error: 'OTP has expired. Please request again.' });
    }
    if (storedOtpData.otp !== otp) {
        // Consider adding rate limiting for incorrect attempts
        return res.status(400).json({ error: 'Invalid OTP entered.' });
    }

    // Success
    delete otpStore[aadhaar]; // Consume the OTP
    session.stage = 'otp_verified';
    console.log(`[OTP Verify] Profile OTP verified successfully for Aadhaar ${aadhaar} (Session: ${sessionId})`);
    res.json({ success: true, message: 'OTP verified.' });
});

app.get('/api/parties', async (req, res) => {
    if (!votingContract || !votingContract.methods?.getAllParties) {
        return res.status(503).json({ error: 'Blockchain service unavailable or contract not initialized.' });
    }
    if (!backendAccount) await setupBackendAccount(); // Ensure account is available
    if (!backendAccount) return res.status(503).json({ error: 'Backend account setup failed.' });

    try {
        console.log(`[API /parties] Fetching parties using account ${backendAccount}`);
        const partiesRaw = await votingContract.methods.getAllParties().call({ from: backendAccount });
        // Ensure returned data is an array before mapping
        const parties = Array.isArray(partiesRaw)
            ? partiesRaw.map(p => ({ id: Number(p.id), name: p.name, abbreviation: p.abbreviation }))
            : [];
        res.json(parties);
    } catch (error) {
        console.error("[API /parties] Error fetching parties from contract:", error.message || error);
        res.status(500).json({ error: 'Failed to fetch parties from blockchain.' });
    }
});

app.post('/api/voter/request-blockchain-key', async (req, res) => {
    // This endpoint sends the *final confirmation code* before casting the vote.
    // It is NOT sending a blockchain private key.
    const { sessionId } = req.body;
    const session = activeVoterSessions[sessionId];

    if (!session || session.stage !== 'otp_verified') {
        return res.status(400).json({ error: 'Invalid session or sequence. Voter profile OTP must be verified first.' });
    }

    const voterData = VOTE_ELIGIBILITY_DB[session.aadhaar];
    if (!voterData || !voterData.mobile || !voterData.email) {
        console.error(`[KEY ERROR] Missing mobile ('${voterData?.mobile}') or email ('${voterData?.email}') for Aadhaar ${session.aadhaar} when requesting confirmation key.`);
        return res.status(500).json({ error: 'Internal error: Voter contact information missing.' });
    }

    const confirmationCode = generateOtp(6); // Using a 6-digit code for usability
    const expiry = Date.now() + 10 * 60 * 1000; // 10 minutes validity
    blockchainKeyStore[sessionId] = { key: confirmationCode, expires: expiry }; // Store it

    console.log(`[KEY] Generated Confirmation Code for Session ${sessionId} (Aadhaar: ${session.aadhaar}): ${confirmationCode}`);

    // Send Confirmation Code via Email and SMS
    let emailSuccess = false;
    let smsSuccess = false;
    try {
        const emailSubject = 'Your Voting Confirmation Code';
        const messagePrefix = 'Your final voting confirmation code is:';

        emailSuccess = await sendEmailOTP(voterData.email, confirmationCode, emailSubject, messagePrefix);
        smsSuccess = await sendSMSOTP(voterData.mobile, confirmationCode, messagePrefix);

        if (!emailSuccess && !smsSuccess) {
            console.error(`[KEY FAIL] CRITICAL: Failed to send Confirmation Code via BOTH Email and SMS for Aadhaar ${session.aadhaar}.`);
            delete blockchainKeyStore[sessionId]; // Clean up failed attempt
            return res.status(503).json({ error: 'Service unavailable: Failed to send confirmation code. Please try again later.' });
        }

        if (!emailSuccess) console.warn(`[KEY WARN] Failed to send Confirmation Code email to ${voterData.email}.`);
        if (!smsSuccess) console.warn(`[KEY WARN] Failed to send Confirmation Code SMS to ${voterData.mobile}. (Check Twilio config/trial limits/verified numbers).`);

        session.stage = 'key_sent'; // Update session stage
        res.json({ success: true, message: `Confirmation code sent successfully ${emailSuccess ? 'to email' : ''}${emailSuccess && smsSuccess ? ' and ' : ''}${smsSuccess ? 'to mobile' : ''}.` });

    } catch (error) {
        console.error(`[KEY ERROR] Unexpected error during Confirmation Code sending process for Aadhaar ${session.aadhaar}:`, error);
        delete blockchainKeyStore[sessionId]; // Clean up potentially stored key
        res.status(500).json({ error: 'An unexpected server error occurred while sending the confirmation code.' });
    }
});

app.post('/api/voter/cast-vote', async (req, res) => {
    const { sessionId, partyId, blockchainKey } = req.body; // 'blockchainKey' is the confirmation code user enters

    // Validate input
    if (!sessionId || !partyId || !blockchainKey) {
        return res.status(400).json({ error: 'Missing sessionId, partyId, or confirmation key in request.' });
    }
    if (isNaN(parseInt(partyId, 10))) {
         return res.status(400).json({ error: 'Invalid partyId format.' });
    }


    // Check contract readiness
    if (!votingContract?.methods?.castVote || !votingContract?.methods?.hasVoted) {
        return res.status(503).json({ error: 'Blockchain service unavailable or contract methods not found.' });
    }
    // Ensure backend account is ready
    if (!backendAccount) await setupBackendAccount();
    if (!backendAccount) return res.status(503).json({ error: 'Backend account setup failed.' });


    // Validate session and stage
    const session = activeVoterSessions[sessionId];
    if (!session || (session.stage !== 'key_sent' && session.stage !== 'key_verified')) { // Allow retry if key verified but tx failed
        return res.status(400).json({ error: 'Invalid session or sequence. Please request the confirmation key first.' });
    }

    // Validate Confirmation Key (which is stored in blockchainKeyStore)
    const storedKeyData = blockchainKeyStore[sessionId];
    if (!storedKeyData) {
        // Key might be missing if already used or expired. Check if already voted.
        if (session.aadhaar) {
            const voterIdentifierHash = generateVoterIdentifierHash(session.aadhaar);
            try {
                 const hasAlreadyVoted = await votingContract.methods.hasVoted(voterIdentifierHash).call({ from: backendAccount });
                 if (hasAlreadyVoted) {
                      delete activeVoterSessions[sessionId]; // Clean up session
                      return res.status(403).json({ error: 'Forbidden: This voter profile has already cast a vote.' });
                 }
            } catch (checkError) {
                console.error("[VOTE CHECK ERROR] Error checking vote status:", checkError.message || checkError);
                // Proceed to check key expiry/validity anyway
            }
        }
        return res.status(400).json({ error: 'Confirmation key session not found or expired. Please request the key again.' });
    }

    if (storedKeyData.expires < Date.now()) {
        delete blockchainKeyStore[sessionId]; // Clean expired key
        return res.status(400).json({ error: 'Confirmation key has expired. Please request it again.' });
    }
    if (storedKeyData.key !== blockchainKey) {
        return res.status(400).json({ error: 'Invalid Confirmation Key entered.' });
    }

    // --- Confirmation Key Verified - Proceed with Vote ---
    session.stage = 'key_verified'; // Mark stage
    delete blockchainKeyStore[sessionId]; // Consume the key

    const voterAadhaar = session.aadhaar;
    const voterIdentifierHash = generateVoterIdentifierHash(voterAadhaar); // Generate the on-chain identifier
    const targetPartyId = parseInt(partyId, 10);

    console.log(`[VOTE] Confirmation Key verified for Aadhaar ${voterAadhaar}. Attempting vote for Party ${targetPartyId} (Hash: ${voterIdentifierHash.substring(0,10)}...)`);

    try {
        // Final check: Has the voter already voted?
        const hasAlreadyVoted = await votingContract.methods.hasVoted(voterIdentifierHash).call({ from: backendAccount });
        if (hasAlreadyVoted) {
            console.log(`[VOTE REJECTED] Voter ${voterAadhaar} (Hash: ${voterIdentifierHash.substring(0,10)}...) already voted (final check).`);
            delete activeVoterSessions[sessionId];
            return res.status(403).json({ error: 'Forbidden: This voter profile has already cast a vote.' });
        }

        // Estimate gas and send transaction
        console.log(`[VOTE] Submitting 'castVote' transaction from backend account ${backendAccount}...`);
        const estimatedGas = await votingContract.methods.castVote(voterIdentifierHash, targetPartyId).estimateGas({ from: backendAccount });
        const gasLimit = Math.max(300000, Math.floor(Number(estimatedGas) * 1.2)); // Use estimate + 20% buffer, min 300k
        console.log(`[VOTE] Estimated Gas: ${estimatedGas}, Using Gas Limit: ${gasLimit}`);

        const receipt = await votingContract.methods.castVote(voterIdentifierHash, targetPartyId).send({
            from: backendAccount,
            gas: gasLimit
        });

        console.log(`[VOTE SUCCESS] Vote cast successfully for Aadhaar ${voterAadhaar}! Tx Hash: ${receipt.transactionHash}`);

        // Clean up successful session
        delete activeVoterSessions[sessionId];

        res.json({
            success: true,
            ballotId: receipt.transactionHash, // Provide transaction hash as proof
            message: 'Your vote has been successfully and securely recorded on the blockchain!'
        });

    } catch (error) {
        console.error("[VOTE ERROR] Blockchain transaction failed:", error.message || error);
        let userErrorMessage = 'Failed to record vote on the blockchain. Please try again later.';

        if (error.receipt) { // Transaction was mined but reverted
            console.error("  Transaction Receipt:", error.receipt);
            userErrorMessage = "Blockchain transaction failed (reverted on-chain).";
        } else if (error.message) {
            if (error.message.includes("revert")) {
                userErrorMessage = 'Blockchain transaction reverted.';
                if (error.message.includes("already cast a vote")) {
                    userErrorMessage = 'Error: Blockchain indicates this voter has already voted.';
                    delete activeVoterSessions[sessionId]; // Clean up session if confirmed voted
                } else if (error.message.includes("invalid party")) {
                    userErrorMessage = 'Error: The selected party ID is invalid according to the contract.';
                } else if (error.message.includes("Voting is not active")) {
                    userErrorMessage = 'Error: Voting is not currently active according to the contract.';
                } else {
                     // Try to extract specific revert reason if possible (might need custom contract events/errors)
                     const reasonMatch = error.message.match(/revert (.+)/);
                     if(reasonMatch && reasonMatch[1]) {
                         userErrorMessage = `Blockchain transaction reverted: ${reasonMatch[1]}`;
                     }
                }
            } else if (error.message.includes("gas") || error.message.includes("out of gas")) {
                userErrorMessage = 'Blockchain transaction failed due to gas calculation issues. Please try again later.';
            } else if (error.message.includes("insufficient funds")) {
                userErrorMessage = 'Blockchain transaction failed: Backend account has insufficient funds to pay for gas.';
            } else if (error.message.includes("nonce")) {
                 userErrorMessage = 'Blockchain transaction failed due to a network nonce issue. Please try again.';
            } else if (error.message.includes("timeout") || error.message.includes("CONNECTION ERROR")) {
                 userErrorMessage = 'Network error communicating with the blockchain. Please check connection and try again.';
            }
        }
        // Allow user to potentially retry if it wasn't an "already voted" error.
        // Session stage remains 'key_verified', but key was consumed, so they need to request it again.
        res.status(500).json({ error: userErrorMessage });
    }
});


// === Admin Flow ===

app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'Missing username or password.' });
    }

    const adminData = ADMIN_DB[username];

    // !!! SECURITY: Replace with bcrypt.compare(password, adminData.hashedPassword) in production !!!
    if (adminData && adminData.password === password) {
        console.log(`[ADMIN AUTH] Credentials verified for admin: ${username}`);

        if (!adminData.email) {
            console.error(`[ADMIN OTP ERROR] Missing email configuration for admin ${username}`);
            return res.status(500).json({ error: 'Internal configuration error: Admin email missing.' });
        }

        const otp = generateOtp();
        const expiry = Date.now() + 5 * 60 * 1000; // 5 minutes
        otpStore[username] = { otp: otp, expires: expiry, type: 'admin' };
        console.log(`[OTP] Generated Admin Login OTP for ${adminData.email}: ${otp}`);

        // Send Admin OTP via Email
        try {
            const emailSent = await sendEmailOTP(adminData.email, otp, 'Admin Login OTP', 'Your admin login OTP is:');
            if (!emailSent) {
                console.error(`[ADMIN OTP FAIL] Failed to send OTP email to ${adminData.email} for admin ${username}. Check email config/credentials.`);
                delete otpStore[username];
                return res.status(503).json({ error: 'Service unavailable: Failed to send Admin OTP email.' });
            }
            res.json({ success: true, message: 'Admin credentials verified. OTP sent to registered email.' });
        } catch (error) {
            console.error(`[ADMIN OTP ERROR] Unexpected error during admin OTP sending for ${username}:`, error);
            delete otpStore[username];
            res.status(500).json({ error: 'An unexpected server error occurred while sending the admin OTP.' });
        }
    } else {
        console.log(`[ADMIN AUTH] Invalid credentials attempt for username: ${username}`);
        res.status(401).json({ error: 'Invalid admin username or password.' });
    }
});

app.post('/api/admin/verify-otp', (req, res) => {
    const { username, otp } = req.body;
    if (!username || !otp) {
        return res.status(400).json({ error: 'Missing username or otp.' });
    }

    const storedOtpData = otpStore[username];
    if (!storedOtpData || storedOtpData.type !== 'admin') {
        return res.status(400).json({ error: 'Admin OTP not found or invalid type. Please login again.' });
    }
    if (storedOtpData.expires < Date.now()) {
        delete otpStore[username];
        return res.status(400).json({ error: 'Admin OTP has expired. Please login again.' });
    }
    if (storedOtpData.otp !== otp) {
        return res.status(400).json({ error: 'Invalid Admin OTP entered.' });
    }

    // Success
    delete otpStore[username]; // Consume OTP
    const adminToken = generateToken(32);
    // Store session with expiry in a real DB
    activeAdminSessions[adminToken] = { username: username, loggedInAt: Date.now() };
    console.log(`[ADMIN OTP Verify] Admin ${username} successfully verified. Session token generated.`);
    res.json({ success: true, token: adminToken, message: 'Admin login successful.' });
});

app.get('/api/admin/results', verifyAdminToken, async (req, res) => {
    // verifyAdminToken middleware already ran and attached req.adminUsername
    console.log(`[ADMIN RESULTS] Request received from admin: ${req.adminUsername}`);

    if (!votingContract?.methods?.getAllParties || !votingContract?.methods?.getVoteCount) {
        return res.status(503).json({ error: 'Blockchain service unavailable or contract methods not found.' });
    }
    if (!backendAccount) await setupBackendAccount();
    if (!backendAccount) return res.status(503).json({ error: 'Backend account setup failed.' });

    try {
        const partiesRaw = await votingContract.methods.getAllParties().call({ from: backendAccount });
        if (!Array.isArray(partiesRaw)) {
             throw new Error("getAllParties did not return an array.");
        }

        const results = [];
        let totalVotes = 0;

        // Fetch vote counts concurrently
        const voteCountPromises = partiesRaw.map(party =>
            votingContract.methods.getVoteCount(Number(party.id)).call({ from: backendAccount })
                .catch(err => { // Handle potential errors fetching individual counts
                    console.error(`Error fetching vote count for party ${party.id}:`, err.message);
                    return BigInt(0); // Return 0 if count fails for a party
                })
        );
        const voteCounts = await Promise.all(voteCountPromises);

        partiesRaw.forEach((party, index) => {
            const voteCount = Number(voteCounts[index] || 0); // Default to 0 if promise rejected
            results.push({
                id: Number(party.id),
                name: party.name,
                abbreviation: party.abbreviation,
                votes: voteCount
            });
            totalVotes += voteCount;
        });

        console.log(`[ADMIN RESULTS] Successfully fetched results for admin: ${req.adminUsername}`);
        res.json({ success: true, results, totalVotes });
    } catch (error) {
        console.error("[API /admin/results] Error fetching results from contract:", error.message || error);
        res.status(500).json({ error: 'Failed to fetch results from blockchain.' });
    }
});

app.post('/api/admin/logout', verifyAdminToken, (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token && activeAdminSessions[token]) {
        delete activeAdminSessions[token];
        console.log(`[ADMIN LOGOUT] Admin ${req.adminUsername} logged out successfully.`);
        res.json({ success: true, message: 'Admin logged out successfully.' });
    } else {
        // This case should be rare if verifyAdminToken works, but handle defensively
        console.warn(`[ADMIN LOGOUT] Attempt to logout with invalid/missing token for user ${req.adminUsername || 'unknown'}`);
        res.status(400).json({ error: 'Invalid session or token for logout.' });
    }
});


// --- Server Initialization ---

/** Initializes all necessary components and starts the Express server */
async function initializeAndStartServer() {
    console.log("[Init] Starting server initialization...");

    // 1. Load Contract ABI
    loadContractABI(); // Exits on failure

    // 2. Initialize Web3 and Contract
    initializeWeb3AndContract(); // Exits on failure

    // 3. Setup Backend Account
    await setupBackendAccount(); // Exits on failure

    // 4. Start Express Server
    app.listen(port, () => {
        console.log(`\n--- Decentralized Voting Backend Ready ---`);
        console.log(`Server running at http://localhost:${port}`);
        console.log(`Connected to RPC: ${GANACHE_RPC_URL}`);
        console.log(`Using contract at address: ${CONTRACT_ADDRESS}`);
        console.log(`Backend Operator Account: ${backendAccount}`);

        // Final check for OTP service credentials
        if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
             console.warn("!!! WARNING: EMAIL_USER or EMAIL_PASS missing/invalid in .env. Email OTPs will fail.");
        }
        if (!twilioClient || !process.env.TWILIO_PHONE_NUMBER) {
             console.warn("!!! WARNING: Twilio not fully configured in .env (SID/Token/Number). SMS OTPs will fail or be disabled.");
        } else {
             console.log("[Init] Email & Twilio environment variables seem loaded (check values & trial status).");
        }
         if (!process.env.ELECTION_SALT || process.env.ELECTION_SALT === "DEFAULT_FALLBACK_SALT_NEEDS_REPLACING") {
             console.warn("!!! SECURITY WARNING: ELECTION_SALT is missing or using default in .env. Set a unique secret value.");
         }
        console.log("-----------------------------------------");
    });
}

// --- Run the Server ---
initializeAndStartServer().catch(error => {
    console.error("!!! FATAL ERROR during server startup:", error);
    process.exit(1);
});




















































// // backend/server.js
// const express = require('express');
// const cors = require('cors');
// const crypto = require('crypto');
// const { Web3 } = require('web3');
// const fs = require('fs');
// const path = require('path');
// require('dotenv').config(); // <-- Load .env variables
// const nodemailer = require('nodemailer'); // <-- Add Nodemailer
// const twilio = require('twilio'); // <-- Add Twilio

// const app = express();
// const port = 3001;

// app.use(cors());
// app.use(express.json());

// // --- Blockchain Configuration ---
// const GANACHE_RPC_URL = 'http://127.0.0.1:7545';
// const CONTRACT_ADDRESS = '0x77A634c377e9D732ED0a313966B2DF9840E6D3F6'; // Ensure this is your LATEST deployed address

// // --- Load Contract ABI ---
// let votingContractABI;
// try {
//     const abiPath = path.resolve(__dirname, '../build/contracts/VotingContract.json');
//     const contractJson = JSON.parse(fs.readFileSync(abiPath, 'utf8'));
//     votingContractABI = contractJson.abi;
//     console.log("Successfully loaded Contract ABI.");
// } catch (err) {
//     console.error("!!! FATAL ERROR: Could not load contract ABI from build file.", err);
//     console.error("!!! Ensure you have run 'truffle compile' and 'truffle migrate' successfully in the parent directory.");
//     process.exit(1);
// }

// // --- Initialize Web3 and Contract ---
// let web3;
// let votingContract;
// let backendAccount;
// try {
//     web3 = new Web3(GANACHE_RPC_URL);
//     if (!CONTRACT_ADDRESS || CONTRACT_ADDRESS === 'PASTE_YOUR_DEPLOYED_CONTRACT_ADDRESS_HERE' || CONTRACT_ADDRESS.length !== 42) { // Basic address check
//          console.error("!!! FATAL ERROR: CONTRACT_ADDRESS is not set correctly in backend/server.js!");
//          console.error("!!! Please paste the address from 'truffle migrate' output. It should be 42 characters long, starting with 0x.");
//          process.exit(1);
//     }
//     votingContract = new web3.eth.Contract(votingContractABI, CONTRACT_ADDRESS);
//     console.log("Web3 initialized and Contract object created.");
// } catch (err) {
//     console.error("!!! FATAL ERROR connecting to Ganache RPC or creating contract object:", err.message);
//     console.error("!!! Ensure Ganache is running at", GANACHE_RPC_URL);
//     process.exit(1);
// }


// // --- Simulated Database (Improved Consistency: Added +91 to all mobile numbers) ---
// const VOTE_ELIGIBILITY_DB = {
//     '878801102299': { name: 'Vishnu Kumar D S', dob: '31/03/2003', mobile: '+919902468983', email: 'vishnukumardsvishnu@gmail.com', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043', aadhaar: '878801102298' },
//     '517782263844': { name: 'Darshan KV', dob: '16/06/2003', mobile: '+917204232086', email: 'darshankvdarshankv59@gmail.com', aadhaar: '517782263844', address: 'hennur cross, 560043, Bengaluru.' },
//     '266017783020': { name: 'Vikas S', dob: '10/03/2003', mobile: '+919742390432', email: 'vikassvikasvijay@gmail.com', aadhaar: '266017783020', address: '#2 VB Hemavathi building Suvarna Nagar Doda bidru kallu Nagsandra Post 560073 Bengaluru.' },
//     '878801182298': { name: 'Soma Shekar', dob: '31/03/2003', mobile: '+919036634209', email: 'somutakur5926@gmail.com', aadhaar: '878801182298', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043'},
//     '989812345678': { name: 'Rahul navi', dob: '22/11/2002', mobile: '+918088122635', email: 'rahulnavi92@gmail.com', address: '23, Indiranagar, Bengaluru 560038', aadhaar: '989812345678' },
//     '894567231901': { name: 'Kaushik K H', dob: '05/05/2001', mobile: '+919740453872', email: 'kaushikkh1431@gmail.com', address: 'Flat 302, MG Residency, BTM Layout, Bengaluru 560076', aadhaar: '894567231901' },
//     '776543213456': { name: 'Vinay ', dob: '18/09/2000', mobile: '+917625071517', email: 'vinaynaikcr7@gmail.com', address: '12, Jayanagar 4th Block, Bengaluru 560011', aadhaar: '776543213456' },
//     '556789009876': { name: 'Kumar', dob: '15/08/2002', mobile: '+919392433367', email: 'mekelakumarreddy@gmail.com', address: 'A-16, KR Puram, Bengaluru 560036', aadhaar: '556789009876' },
//     '449988776655': { name: 'Anil', dob: '09/01/2001', mobile: '+919980146855', email: 'anilkumarn6855@mail.com', address: 'B-42, Whitefield Main Road, Bengaluru 560066', aadhaar: '449988776655' }, // Added +91
//     '332211009988': { name: 'Kammar Rao', dob: '03/03/2000', mobile: '+917022800262', email: 'kiranrao93@gmail.com', address: '14, JP Nagar Phase 6, Bengaluru 560078', aadhaar: '332211009988' }, // Added +91
//     '221199887766': { name: 'Meghana K', dob: '12/07/2003', mobile: '+919495969789', email: 'meghana.k@gmail.com', address: 'No. 5, Marathahalli ORR, Bengaluru 560037', aadhaar: '221199887766' } // Added +91
// };
// // Admin DB - REMINDER: Plain text password is insecure for production! Use hashing (bcrypt).
// const ADMIN_DB = {
//     'vishnu123': { password: '@Vishnu89', name: 'Vishnu Reddy', dob: '02/28/2003', email: 'gowthamg78657g@gmail.com', number: '+919392433367' } // Added +91 for consistency
// };

// const otpStore = {};
// const blockchainKeyStore = {};
// const activeVoterSessions = {};
// const activeAdminSessions = {};

// // --- Helper Functions ---
// function generateOtp(length = 6) { return crypto.randomInt(10**(length-1), 10**length).toString(); }
// function generateToken(length = 32) { return crypto.randomBytes(length).toString('hex'); }
// function generateVoterIdentifierHash(aadhaar) {
//     // This salt should ideally be unique per election and kept secret (e.g., in .env)
//     const ELECTION_SALT = process.env.ELECTION_SALT || "DEFAULT_FALLBACK_SALT_NEEDS_REPLACING"; // Use env var or a secure default
//     const hash = crypto.createHash('sha256').update(aadhaar + ELECTION_SALT).digest('hex');
//     return '0x' + hash;
// }
// function verifyAdminToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
//     if (!token) return res.status(401).json({ error: 'Unauthorized: No token provided.' });
//     const session = activeAdminSessions[token];
//     // Add check for token expiry in a real application
//     if (!session) return res.status(401).json({ error: 'Unauthorized: Invalid or expired token.' });
//     req.adminUsername = session.username;
//     next();
//  }

// // --- OTP Sending Functions ---

// // Configure Nodemailer transporter
// const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//         user: process.env.EMAIL_USER,
//         pass: process.env.EMAIL_PASS, // MUST be App Password for Gmail if 2FA is enabled
//     },
// });

// // Configure Twilio client
// let twilioClient;
// if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
//     twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
//     console.log("[Twilio] Client initialized.");
// } else {
//     console.warn("[Twilio] WARNING: Twilio Account SID or Auth Token missing in .env. SMS sending disabled.");
//     // Assign a dummy client or handle appropriately if needed
//     twilioClient = null;
// }


// async function sendEmailOTP(email, otp, subject = 'Your OTP Code', bodyPrefix = 'Your OTP is:') {
//     if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
//         console.error("[EMAIL ERROR] Cannot send email. EMAIL_USER or EMAIL_PASS missing in .env");
//         return false;
//     }
//     const mailOptions = {
//         from: `"Decentralized Voting System" <${process.env.EMAIL_USER}>`,
//         to: email,
//         subject: subject,
//         text: `${bodyPrefix} ${otp}\nThis code will expire in 5 minutes.`,
//         html: `<p>${bodyPrefix} <b>${otp}</b></p><p>This code will expire in 5 minutes.</p>`,
//     };

//     try {
//         let info = await transporter.sendMail(mailOptions);
//         console.log(`[EMAIL] OTP sent to ${email}. Message ID: ${info.messageId}`);
//         return true; // Indicate success
//     } catch (error) {
//         console.error(`[EMAIL ERROR] Failed to send OTP to ${email}:`, error.message || error);
//         return false; // Indicate failure
//     }
// }

// async function sendSMSOTP(phoneNumber, otp, bodyPrefix = 'Your Voting App OTP is:') {
//     // Check if Twilio is configured and phoneNumber is provided
//      if (!twilioClient || !process.env.TWILIO_PHONE_NUMBER) {
//         console.warn(`[SMS WARN] Cannot send SMS to ${phoneNumber}. Twilio client not initialized or TWILIO_PHONE_NUMBER missing in .env.`);
//         return false;
//     }
//      if (!phoneNumber) {
//          console.warn(`[SMS WARN] Cannot send SMS. Recipient phone number is missing.`);
//          return false;
//      }


//     // Ensure E.164 format (starts with +country_code)
//     let formattedPhoneNumber = phoneNumber.trim();
//     if (!formattedPhoneNumber.startsWith('+')) {
//         // Assuming Indian numbers if no country code provided
//         if (formattedPhoneNumber.length === 10) {
//              formattedPhoneNumber = `+91${formattedPhoneNumber}`;
//              console.log(`[SMS Format] Added +91 prefix to: ${phoneNumber} -> ${formattedPhoneNumber}`);
//         } else {
//              console.error(`[SMS ERROR] Invalid phone number format for Twilio: ${phoneNumber}. Needs E.164 format (e.g., +91...)`);
//              return false;
//         }
//     }

//     try {
//         const message = await twilioClient.messages.create({
//             body: `${bodyPrefix} ${otp}. Valid for 5 mins.`,
//             from: process.env.TWILIO_PHONE_NUMBER, // Your Twilio number (Sender ID)
//             to: formattedPhoneNumber,           // Recipient number
//         });
//         console.log(`[SMS] OTP sent to ${formattedPhoneNumber}. SID: ${message.sid}`);
//         return true; // Indicate success
//     } catch (error) {
//         console.error(`[SMS ERROR] Failed to send OTP to ${formattedPhoneNumber}:`, error.message || error);
//         // Log specific Twilio errors if available
//         if (error.code) {
//             console.error(`  Twilio Error Code: ${error.code}`);
//              console.error(`  More Info: ${error.moreInfo}`);
//              if (error.code === 21608) { // Unverified number for Trial account
//                  console.error("  >>>>> This recipient number needs to be verified in your Twilio Trial account dashboard! <<<<<");
//              } else if (error.code === 21211) { // Invalid 'To' number
//                   console.error("  >>>>> The recipient phone number format might be invalid. <<<<<");
//              } else if (error.code === 21408) { // Permission Denied
//                   console.error("  >>>>> Your Twilio account might lack permission to send to this region/number. <<<<<");
//              }
//         }
//         return false; // Indicate failure
//     }
// }


// // --- API Endpoints ---
// app.get('/api/ping', (req, res) => res.json({ message: 'Backend is running!' }));

// // === Voter Flow ===
// app.post('/api/voter/check-aadhaar', (req, res) => {
//     const { aadhaar } = req.body;
//     if (!aadhaar || !/^\d{12}$/.test(aadhaar)) {
//         return res.status(400).json({ error: 'Invalid Aadhaar format (must be 12 digits).' });
//     }
//     const voterData = VOTE_ELIGIBILITY_DB[aadhaar];
//     if (voterData) {
//         const sessionId = generateToken(16);
//         // Store only necessary info, maybe not full voter data in session?
//         activeVoterSessions[sessionId] = { aadhaar: aadhaar, stage: 'aadhaar_verified' };
//         console.log(`[AUTH] Aadhaar ${aadhaar} verified. Session created: ${sessionId}`);
//         res.json({ success: true, sessionId: sessionId });
//     } else {
//         console.log(`[AUTH] Aadhaar ${aadhaar} not found in eligible list.`);
//         res.status(404).json({ error: 'Aadhaar number not found in eligible voter list.' });
//     }
// });

// app.post('/api/voter/request-profile-otp', async (req, res) => {
//     const { sessionId } = req.body;
//     const session = activeVoterSessions[sessionId];

//     if (!session || session.stage !== 'aadhaar_verified') {
//         return res.status(400).json({ error: 'Invalid session or sequence.' });
//     }

//     const voterData = VOTE_ELIGIBILITY_DB[session.aadhaar];
//     // Added more robust check for contact info
//     if (!voterData || !voterData.mobile || !voterData.email) {
//         console.error(`[OTP ERROR] Missing mobile ('${voterData?.mobile}') or email ('${voterData?.email}') for Aadhaar ${session.aadhaar}`);
//         return res.status(500).json({ error: 'Internal error: Voter contact information missing or incomplete.' });
//     }

//     const otp = generateOtp();
//     const expiry = Date.now() + 5 * 60 * 1000; // 5 minutes validity
//     otpStore[session.aadhaar] = { otp: otp, expires: expiry, type: 'voter' };

//     console.log(`[OTP] Generated Voter Profile OTP for ${session.aadhaar}: ${otp}`);

//     // --- Send OTP via Email and SMS ---
//     let emailSuccess = false;
//     let smsSuccess = false;
//     try {
//         emailSuccess = await sendEmailOTP(voterData.email, otp, 'Your Voter Profile OTP', 'Your profile verification OTP is:');
//         smsSuccess = await sendSMSOTP(voterData.mobile, otp, 'Your Voter Profile OTP is:');

//         if (!emailSuccess && !smsSuccess) {
//              console.error(`[OTP FAIL] CRITICAL: Failed to send OTP via BOTH Email and SMS for Aadhaar ${session.aadhaar}.`);
//              delete otpStore[session.aadhaar];
//              return res.status(503).json({ error: 'Failed to send OTP. Please check contact details or try again later.' });
//         }
//         // Log warnings if one method failed
//         if (!emailSuccess) console.warn(`[OTP WARN] Failed to send OTP email to ${voterData.email}.`);
//         if (!smsSuccess) console.warn(`[OTP WARN] Failed to send OTP SMS to ${voterData.mobile}. Check Twilio config/trial limits.`);

//         // Proceed if at least one method succeeded
//         session.stage = 'otp_sent';
//         res.json({
//             success: true,
//             message: 'OTP sent to your registered mobile number and/or email address.', // Slightly adjusted message
//             profile: {
//                 name: voterData.name,
//                 dob: voterData.dob,
//                 address: voterData.address,
//                 mobileMasked: voterData.mobile ? '******' + voterData.mobile.slice(-4) : 'N/A', // Handle missing mobile
//                 emailMasked: voterData.email ? voterData.email.split('@')[0].slice(0, 3) + '***@' + voterData.email.split('@')[1] : 'N/A' // Handle missing email
//             }
//         });

//     } catch (error) { // Catch unexpected errors during the process
//         console.error(`[OTP ERROR] Unexpected error during OTP sending process for Aadhaar ${session.aadhaar}:`, error);
//         delete otpStore[session.aadhaar];
//         res.status(500).json({ error: 'An unexpected server error occurred while sending the OTP.' });
//     }
// });

// // ... (verify-otp endpoint remains the same) ...
// app.post('/api/voter/verify-otp', (req, res) => {
//     const { sessionId, otp } = req.body;
//     const session = activeVoterSessions[sessionId];

//     if (!session || session.stage !== 'otp_sent') {
//         return res.status(400).json({ error: 'Invalid session or sequence.' });
//     }

//     const aadhaar = session.aadhaar;
//     const storedOtpData = otpStore[aadhaar];

//     if (!storedOtpData || storedOtpData.type !== 'voter') {
//         return res.status(400).json({ error: 'OTP not found or invalid type. Please request again.' });
//     }
//     if (storedOtpData.expires < Date.now()) {
//         delete otpStore[aadhaar]; // Clean up expired OTP
//         return res.status(400).json({ error: 'OTP has expired. Please request again.' });
//     }
//     if (storedOtpData.otp !== otp) {
//         // Maybe add rate limiting here in a real app
//         return res.status(400).json({ error: 'Invalid OTP entered.' });
//     }

//     // Success!
//     delete otpStore[aadhaar]; // OTP used, remove it
//     session.stage = 'otp_verified';
//     console.log(`[OTP Verify] Voter OTP verified successfully for Aadhaar ${aadhaar}`);
//     res.json({ success: true, message: 'OTP verified.' });
// });


// // ... (parties endpoint remains the same) ...
// app.get('/api/parties', async (req, res) => {
//     if (!votingContract || !votingContract.methods || !votingContract.methods.getAllParties) {
//         return res.status(503).json({ error: 'Blockchain service unavailable or contract not fully initialized.' });
//     }
//     try {
//         // Ensure backendAccount is set before calling
//         if (!backendAccount) {
//              await setupBackendAccount(); // Attempt to set it up if missing
//              if (!backendAccount) {
//                  return res.status(503).json({ error: 'Backend account not available for blockchain interaction.' });
//              }
//         }
//         const partiesRaw = await votingContract.methods.getAllParties().call({ from: backendAccount });
//         const parties = partiesRaw.map(p => ({ id: Number(p.id), name: p.name, abbreviation: p.abbreviation }));
//         res.json(parties);
//     } catch (error) {
//         console.error("[API /parties] Error fetching parties from contract:", error.message || error);
//         res.status(500).json({ error: 'Failed to fetch parties from blockchain.' });
//     }
//  });


// // ... (request-blockchain-key endpoint - similar logic to request-profile-otp) ...
// app.post('/api/voter/request-blockchain-key', async (req, res) => {
//     const { sessionId } = req.body;
//     const session = activeVoterSessions[sessionId];

//     if (!session || session.stage !== 'otp_verified') {
//         return res.status(400).json({ error: 'Invalid session or sequence. OTP must be verified first.' });
//     }

//     const voterData = VOTE_ELIGIBILITY_DB[session.aadhaar];
//     if (!voterData || !voterData.mobile || !voterData.email) {
//         console.error(`[KEY ERROR] Missing mobile ('${voterData?.mobile}') or email ('${voterData?.email}') for Aadhaar ${session.aadhaar} when requesting key.`);
//         return res.status(500).json({ error: 'Internal error: Voter contact information missing.' });
//     }

//     // Generate a shorter, easier-to-type key (like an OTP) for confirmation
//     const key = generateOtp(6); // Using OTP generation for the key
//     const expiry = Date.now() + 10 * 60 * 1000; // 10 minutes validity
//     blockchainKeyStore[sessionId] = { key: key, expires: expiry };

//     console.log(`[KEY] Generated Blockchain Confirmation Key for Session ${sessionId} (Aadhaar: ${session.aadhaar}): ${key}`);

//     // --- Send Key via Email and SMS ---
//     let emailSuccess = false;
//     let smsSuccess = false;
//     try {
//         const emailSubject = 'Your Voting Confirmation Key';
//         const messagePrefix = 'Your blockchain voting confirmation key is:';

//         emailSuccess = await sendEmailOTP(voterData.email, key, emailSubject, messagePrefix);
//         smsSuccess = await sendSMSOTP(voterData.mobile, key, messagePrefix);

//         if (!emailSuccess && !smsSuccess) {
//             console.error(`[KEY FAIL] CRITICAL: Failed to send confirmation key via BOTH Email and SMS for Aadhaar ${session.aadhaar}.`);
//             delete blockchainKeyStore[sessionId]; // Clean up if sending failed
//             return res.status(503).json({ error: 'Failed to send confirmation key. Please try again later.' });
//         }
//          if (!emailSuccess) console.warn(`[KEY WARN] Failed to send key email to ${voterData.email}.`);
//          if (!smsSuccess) console.warn(`[KEY WARN] Failed to send key SMS to ${voterData.mobile}. Check Twilio config/trial limits.`);


//         // Proceed if at least one method worked
//         session.stage = 'key_sent';
//         res.json({ success: true, message: 'Blockchain confirmation key sent to your mobile and/or email.' });

//     } catch (error) {
//         console.error(`[KEY ERROR] Unexpected error during key sending process for Aadhaar ${session.aadhaar}:`, error);
//         delete blockchainKeyStore[sessionId]; // Clean up
//         res.status(500).json({ error: 'An unexpected server error occurred while sending the confirmation key.' });
//     }
// });


// // ... (cast-vote endpoint remains largely the same, ensure backendAccount check) ...
// app.post('/api/voter/cast-vote', async (req, res) => {
//     const { sessionId, partyId, blockchainKey } = req.body;

//     if (!votingContract || !votingContract.methods || !votingContract.methods.castVote || !votingContract.methods.hasVoted) {
//         return res.status(503).json({ error: 'Blockchain service unavailable or contract not fully initialized.' });
//     }
//      // Ensure backendAccount is set before calling
//      if (!backendAccount) {
//           await setupBackendAccount(); // Attempt to set it up if missing
//           if (!backendAccount) {
//               return res.status(503).json({ error: 'Backend account not available for blockchain interaction.' });
//           }
//      }


//     const session = activeVoterSessions[sessionId];
//     // Allow casting vote if key was sent OR already verified (e.g., if they retry after a network glitch)
//     if (!session || (session.stage !== 'key_sent' && session.stage !== 'key_verified')) {
//         return res.status(400).json({ error: 'Invalid session or sequence. Request and confirm the blockchain key first.' });
//     }

//     const storedKeyData = blockchainKeyStore[sessionId];
//     if (!storedKeyData) {
//         // Key might be missing if already used or expired
//         // Check if they already voted perhaps? (Added check here)
//         if (session.aadhaar) { // Only check if we have aadhaar in session
//             const voterIdentifierHash = generateVoterIdentifierHash(session.aadhaar);
//             try {
//                  const hasAlreadyVoted = await votingContract.methods.hasVoted(voterIdentifierHash).call({ from: backendAccount });
//                  if (hasAlreadyVoted) {
//                       delete activeVoterSessions[sessionId]; // Clean up session
//                       return res.status(403).json({ error: 'This voter profile has already cast a vote.' });
//                  }
//             } catch (checkError) {
//                 console.error("[VOTE CHECK ERROR] Error checking vote status pre-flight:", checkError.message || checkError);
//                 // Don't necessarily stop the process, but log it
//             }
//         }
//         // If not already voted, the key is genuinely missing/expired
//         return res.status(400).json({ error: 'Blockchain key session not found or expired. Please request the key again.' });
//     }

//     if (storedKeyData.expires < Date.now()) {
//         delete blockchainKeyStore[sessionId]; // Clean up expired key
//         // Don't delete activeVoterSession yet, they might just need a new key
//         return res.status(400).json({ error: 'Blockchain key has expired. Please request it again.' });
//     }
//     if (storedKeyData.key !== blockchainKey) {
//         return res.status(400).json({ error: 'Invalid Blockchain Confirmation Key.' });
//     }

//     // --- Key Verified - Proceed with Vote Casting ---
//     session.stage = 'key_verified'; // Mark as verified
//     // We can now remove the key as it's served its purpose for this session
//     delete blockchainKeyStore[sessionId];

//     const voterAadhaar = session.aadhaar;
//     const voterIdentifierHash = generateVoterIdentifierHash(voterAadhaar);
//     console.log(`[VOTE] Key Verified. Attempting vote for Party ${partyId} by hash ${voterIdentifierHash.substring(0,10)}... (Session: ${sessionId})`);

//     try {
//         // Double check hasn't voted just before sending transaction
//         const hasAlreadyVoted = await votingContract.methods.hasVoted(voterIdentifierHash).call({ from: backendAccount });
//         if (hasAlreadyVoted) {
//             console.log(`[VOTE REJECTED] Hash ${voterIdentifierHash.substring(0,10)}... has already voted (checked just before send).`);
//             delete activeVoterSessions[sessionId]; // Clean up session
//             return res.status(403).json({ error: 'This voter profile has already cast a vote in this election.' });
//         }

//         console.log(`[VOTE] Submitting transaction to cast vote from backend account ${backendAccount}...`);
//         // Estimate gas or use a fixed sufficient amount
//         const estimatedGas = await votingContract.methods.castVote(voterIdentifierHash, partyId).estimateGas({ from: backendAccount });
//         const gasLimit = Math.floor(Number(estimatedGas) * 1.2); // Add 20% buffer

//         const receipt = await votingContract.methods.castVote(voterIdentifierHash, partyId).send({ from: backendAccount, gas: gasLimit });

//         console.log(`[VOTE SUCCESS] Vote cast successfully! Tx Hash: ${receipt.transactionHash}`);

//         // Clean up successful session
//         delete activeVoterSessions[sessionId];

//         res.json({
//             success: true,
//             ballotId: receipt.transactionHash,
//             message: 'Your vote has been successfully and securely recorded on the blockchain!'
//         });

//     } catch (error) {
//         console.error("[VOTE ERROR] Blockchain transaction failed:", error.message || error);
//         // Check if the key needs to be re-issued or session invalidated based on error
//         let errorMessage = 'Failed to record vote on the blockchain. Please try again later.';
//         // More specific revert reasons if available
//          if (error.receipt) { // If receipt exists, tx was mined but reverted
//              console.error("  Transaction Receipt:", error.receipt);
//              errorMessage = "Blockchain transaction failed (reverted).";
//          } else if (error.message && error.message.includes("revert")) {
//              errorMessage = 'Blockchain transaction reverted.';
//             // Attempt to parse known revert reasons
//             if (error.message.includes("already cast a vote")) {
//                 errorMessage = 'Error: Blockchain indicates this voter has already voted.';
//                 delete activeVoterSessions[sessionId];
//             } else if (error.message.includes("invalid party")) {
//                  errorMessage = 'Error: The selected party ID is invalid.';
//             } else if (error.message.includes("Voting is not active")) {
//                 errorMessage = 'Error: Voting is not currently active according to the contract.';
//             }
//         } else if (error.message && (error.message.includes("gas") || error.message.includes("out of gas"))) {
//             errorMessage = 'Blockchain transaction failed due to gas issues. Please try again later.';
//         } else if (error.message && error.message.includes("sender doesn't have enough funds")) {
//              errorMessage = 'Blockchain transaction failed: Backend account has insufficient funds.';
//         }
//         // If the vote failed for reasons other than "already voted", the user might need to retry.
//         // The key was deleted upon verification. Session stage remains 'key_verified' allowing potential retry without re-authentication, but key needs requesting again.
//         // Consider if session stage should revert to 'otp_verified' if key needs re-requesting.
//         res.status(500).json({ error: errorMessage });
//     }
// });



// // === Admin Flow ===
// // ... (admin endpoints remain largely the same, ensure backendAccount check for results) ...
// app.post('/api/admin/login', async (req, res) => {
//     const { username, password } = req.body;
//     const adminData = ADMIN_DB[username];

//     // !!! INSECURE: Replace with bcrypt.compareSync(password, adminData.hashedPassword) in production !!!
//     if (adminData && adminData.password === password) {
//         console.log(`[ADMIN AUTH] Credentials verified for admin: ${username}`);

//         if (!adminData.email) {
//              console.error(`[ADMIN OTP ERROR] Missing email for admin ${username}`);
//              return res.status(500).json({ error: 'Internal configuration error: Admin email missing.' });
//         }

//         const otp = generateOtp();
//         const expiry = Date.now() + 5 * 60 * 1000; // 5 minutes
//         otpStore[username] = { otp: otp, expires: expiry, type: 'admin' };

//         console.log(`[OTP] Generated Admin Login OTP for ${adminData.email}: ${otp}`);

//         // --- Send Admin OTP via Email ---
//         try {
//             const emailSent = await sendEmailOTP(adminData.email, otp, 'Admin Login OTP', 'Your admin login OTP is:');

//             if (!emailSent) {
//                  console.error(`[ADMIN OTP FAIL] Failed to send OTP email to ${adminData.email} for admin ${username}.`);
//                  delete otpStore[username]; // Clean up OTP
//                  return res.status(503).json({ error: 'Failed to send Admin OTP email. Please check configuration or try again.' });
//             }

//             res.json({ success: true, message: 'Admin credentials verified. OTP sent to registered email.' });

//         } catch (error) {
//             console.error(`[ADMIN OTP ERROR] Unexpected error during admin OTP sending for ${username}:`, error);
//             delete otpStore[username]; // Clean up OTP
//             res.status(500).json({ error: 'An unexpected error occurred while sending the admin OTP.' });
//         }

//     } else {
//         console.log(`[ADMIN AUTH] Invalid credentials attempt for username: ${username}`);
//         res.status(401).json({ error: 'Invalid admin username or password.' });
//     }
// });

// app.post('/api/admin/verify-otp', (req, res) => {
//     const { username, otp } = req.body;
//     const storedOtpData = otpStore[username];

//     if (!storedOtpData || storedOtpData.type !== 'admin') {
//         return res.status(400).json({ error: 'Admin OTP not found or invalid type. Please login again.' });
//     }
//     if (storedOtpData.expires < Date.now()) {
//         delete otpStore[username]; // Clean up expired OTP
//         return res.status(400).json({ error: 'Admin OTP has expired. Please login again.' });
//     }
//     if (storedOtpData.otp !== otp) {
//         return res.status(400).json({ error: 'Invalid Admin OTP entered.' });
//     }

//     // Success
//     delete otpStore[username]; // Clean up used OTP
//     const adminToken = generateToken(32);
//     // Store more info in session if needed, add expiry
//     activeAdminSessions[adminToken] = { username: username, loggedInAt: Date.now() };
//     console.log(`[ADMIN OTP Verify] Admin ${username} successfully verified. Session token generated.`);
//     res.json({ success: true, token: adminToken, message: 'Admin login successful.' });
// });

// app.get('/api/admin/results', verifyAdminToken, async (req, res) => {
//     console.log(`[ADMIN RESULTS] Request received from admin: ${req.adminUsername}`);

//     if (!votingContract || !votingContract.methods || !votingContract.methods.getAllParties || !votingContract.methods.getVoteCount) {
//          return res.status(503).json({ error: 'Blockchain service unavailable or contract not fully initialized.' });
//     }
//      // Ensure backendAccount is set before calling
//      if (!backendAccount) {
//           await setupBackendAccount(); // Attempt to set it up if missing
//           if (!backendAccount) {
//               return res.status(503).json({ error: 'Backend account not available for blockchain interaction.' });
//           }
//      }

//     try {
//         const partiesRaw = await votingContract.methods.getAllParties().call({ from: backendAccount });
//         const results = [];
//         let totalVotes = 0;
//         // Use Promise.all for potentially faster fetching if contract allows parallel calls
//         const voteCountPromises = partiesRaw.map(party =>
//              votingContract.methods.getVoteCount(Number(party.id)).call({ from: backendAccount })
//         );
//         const voteCounts = await Promise.all(voteCountPromises);

//         partiesRaw.forEach((party, index) => {
//             const voteCount = Number(voteCounts[index]); // Convert BigInt from promise result
//              results.push({
//                  id: Number(party.id),
//                  name: party.name,
//                  abbreviation: party.abbreviation,
//                  votes: voteCount
//              });
//             totalVotes += voteCount;
//         });

//         console.log(`[ADMIN RESULTS] Successfully fetched results for admin: ${req.adminUsername}`);
//         res.json({ success: true, results, totalVotes });
//     } catch (error) {
//         console.error("[API /admin/results] Error fetching results from contract:", error.message || error);
//         res.status(500).json({ error: 'Failed to fetch results from blockchain.' });
//     }
// });

// app.post('/api/admin/logout', verifyAdminToken, (req, res) => {
//      const authHeader = req.headers['authorization'];
//      const token = authHeader && authHeader.split(' ')[1];
//     if (token && activeAdminSessions[token]) {
//          delete activeAdminSessions[token];
//          console.log(`[ADMIN LOGOUT] Admin ${req.adminUsername} logged out.`);
//          res.json({ success: true, message: 'Admin logged out successfully.' });
//     } else {
//          // Technically verifyAdminToken should catch invalid tokens, but defense in depth
//          res.status(400).json({ error: 'Invalid or missing token for logout.' });
//     }
// });


// // --- Server Start ---
// async function startServer() {
//     await setupBackendAccount(); // Ensure account is ready before listening
//     app.listen(port, () => {
//         console.log(`\n--- Decentralized Voting Backend ---`);
//         console.log(`Server running at http://localhost:${port}`);
//         console.log(`Using contract at address: ${CONTRACT_ADDRESS}`);
//         console.log(`Connected to RPC: ${GANACHE_RPC_URL}`);
//         // Simplified env check
//         if (!process.env.EMAIL_USER || !process.env.TWILIO_ACCOUNT_SID) {
//              console.warn("!!! WARNING: EMAIL_USER or TWILIO_ACCOUNT_SID missing in .env. Corresponding OTP services may fail.");
//         } else {
//              console.log("Email/Twilio environment variables seem loaded.");
//         }
//     });
// }

// // --- Get Ganache accounts ---
// async function setupBackendAccount() {
//     // Prevent multiple setups if called again
//     if (backendAccount) return;

//     try {
//         if (!web3) { // Ensure web3 is initialized
//              throw new Error("Web3 not initialized before setting up account.");
//         }
//         const accounts = await web3.eth.getAccounts();
//         if (!accounts || accounts.length === 0) {
//              throw new Error("No accounts found in Ganache. Ensure Ganache is running and accessible.");
//         }
//         backendAccount = accounts[0]; // Use the first account from Ganache
//         console.log(`Backend configured to use account: ${backendAccount}`);
//         const balanceWei = await web3.eth.getBalance(backendAccount);
//         const balanceEth = web3.utils.fromWei(balanceWei, 'ether');
//         console.log(`Backend account balance: ${balanceEth} ETH`);
//         if (parseFloat(balanceEth) < 0.1) { // Check for a minimal balance
//              console.warn(`!!! WARNING: Backend account ${backendAccount} has low balance (${balanceEth} ETH). Transactions might fail.`);
//         }
//     } catch (error) {
//         console.error("!!! FATAL ERROR setting up backend account from Ganache:", error.message || error);
//         console.error("!!! Ensure Ganache is running at", GANACHE_RPC_URL, "and has accounts.");
//         process.exit(1); // Exit if backend account cannot be set up
//     }
// }

// // --- Initialize ---
// startServer(); // Start the server process


































































































// // backend/server.js
// const express = require('express');
// const cors = require('cors');
// const crypto = require('crypto');
// const { Web3 } = require('web3');
// const fs = require('fs'); // Needed to read the ABI JSON file
// const path = require('path'); // Needed to construct the path to ABI

// const app = express();
// const port = 3001;

// app.use(cors());
// app.use(express.json());

// // --- Blockchain Configuration ---
// const GANACHE_RPC_URL = 'http://127.0.0.1:7545'; // Default Ganache URL

// // !!! IMPORTANT: PASTE THE CONTRACT ADDRESS YOU COPIED FROM `truffle migrate` HERE !!!
// const CONTRACT_ADDRESS = '0xD177d66A32A62cC734DAafCe73aB61D9F073c1E2';

// // --- Load Contract ABI from Truffle build file ---
// let votingContractABI;
// try {
//     // Construct the path relative to the backend folder's location
//     const abiPath = path.resolve(__dirname, '../build/contracts/VotingContract.json');
//     const contractJson = JSON.parse(fs.readFileSync(abiPath, 'utf8'));
//     votingContractABI = contractJson.abi;
//     console.log("Successfully loaded Contract ABI.");
// } catch (err) {
//     console.error("!!! FATAL ERROR: Could not load contract ABI from build file.", err);
//     console.error("!!! Ensure you have run 'truffle compile' and 'truffle migrate' successfully in the parent directory.");
//     process.exit(1);
// }

// // --- Initialize Web3 and Contract ---
// let web3;
// let votingContract;
// let backendAccount;

// try {
//     web3 = new Web3(GANACHE_RPC_URL);
//     if (!CONTRACT_ADDRESS || CONTRACT_ADDRESS === 'PASTE_YOUR_DEPLOYED_CONTRACT_ADDRESS_HERE') {
//          console.error("!!! FATAL ERROR: CONTRACT_ADDRESS is not set in backend/server.js!");
//          console.error("!!! Please paste the address from 'truffle migrate' output.");
//          process.exit(1);
//     }
//     votingContract = new web3.eth.Contract(votingContractABI, CONTRACT_ADDRESS);
//     console.log("Web3 initialized and Contract object created.");
// } catch (err) {
//     console.error("!!! FATAL ERROR connecting to Ganache RPC or creating contract object:", err.message);
//     console.error("!!! Ensure Ganache is running at", GANACHE_RPC_URL);
//     process.exit(1);
// }

// // --- Get Backend Account (from Ganache) ---
// async function setupBackendAccount() {
//    // (Code is the same as previous example - see full code block below)
//    // ... included in the full server.js block below ...
// }

// // --- Simulated Database ---
// const VOTE_ELIGIBILITY_DB = { /* ... Same data as before ... */
//     '878801102298': { name: 'Vishnu Kumar D S', dob: '31/03/2003', mobile: '9902468983', email: 'vishnukumardsvishnu@gmail.com', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043', aadhaar: '878801102298' },
//     '517782263844': { name: 'Darshan KV', dob: '16/06/2003', mobile: '7204232086', email: 'darshankvdarshankv59@gmail.com', aadhaar: '517782263844', address: 'hennur cross, 560043, Bengaluru.' },
//     '266017783020': { name: 'Vikas S', dob: '10/03/2003', mobile: '9742390432', email: 'vikassvikasvijay@gmail.com', aadhaar: '266017783020', address: '#2 VB Hemavathi building Suvarna Nagar Doda bidru kallu Nagsandra Post 560073 Bengaluru.' },
//     '878801182298': { name: 'Soma Shekar', dob: '31/03/2003', mobile: '9036634209', email: 'somutakur5926@gmail.com', aadhaar: '878801182298', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043'},
//         '878801102298': { name: 'Vishnu Kumar D S', dob: '31/03/2003', mobile: '9902468983', email: 'vishnukumardsvishnu@gmail.com', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043', aadhaar: '878801102298' },
//         '517782263844': { name: 'Darshan KV', dob: '16/06/2003', mobile: '7204232086', email: 'darshankvdarshankv59@gmail.com', aadhaar: '517782263844', address: 'Hennur Cross, 560043, Bengaluru.' },
//         '266017783020': { name: 'Vikas S', dob: '10/03/2003', mobile: '9742390432', email: 'vikassvikasvijay@gmail.com', aadhaar: '266017783020', address: '#2 VB Hemavathi Building, Suvarna Nagar, Doda Bidru Kallu, Nagsandra Post, 560073 Bengaluru.' },
//         '878801182298': { name: 'Soma Shekar', dob: '31/03/2003', mobile: '9036634209', email: 'somutakur5926@gmail.com', aadhaar: '878801182298', address: 'Hari Hari PG, Hennur Cross, Bengaluru 560043' },
//         '989812345678': { name: 'Rahul navi', dob: '22/11/2002', mobile: '8088122635', email: 'rahulnavi92@gmail.com', address: '23, Indiranagar, Bengaluru 560038', aadhaar: '989812345678' },
//         '894567231901': { name: 'Kaushik K H', dob: '05/05/2001', mobile: '9740453872', email: 'kaushikkh1431@gmail.com', address: 'Flat 302, MG Residency, BTM Layout, Bengaluru 560076', aadhaar: '894567231901' },
//         '776543213456': { name: 'Vinay ', dob: '18/09/2000', mobile: '7625071517', email: 'vinaynaikcr7@gmail.com', address: '12, Jayanagar 4th Block, Bengaluru 560011', aadhaar: '776543213456' },
//         '556789009876': { name: 'Kumar', dob: '15/08/2002', mobile: '9392433367', email: 'mekelakumarreddy@gmail.com', address: 'A-16, KR Puram, Bengaluru 560036', aadhaar: '556789009876' },
//         '449988776655': { name: 'Anil', dob: '09/01/2001', mobile: '9980146855', email: 'anilkumarn6855@mail.com', address: 'B-42, Whitefield Main Road, Bengaluru 560066', aadhaar: '449988776655' },
//         '332211009988': { name: 'Kammar Rao', dob: '03/03/2000', mobile: '7022800262', email: 'kiranrao93@gmail.com', address: '14, JP Nagar Phase 6, Bengaluru 560078', aadhaar: '332211009988' },
//         '221199887766': { name: 'Meghana K', dob: '12/07/2003', mobile: '9495969789', email: 'meghana.k@gmail.com', address: 'No. 5, Marathahalli ORR, Bengaluru 560037', aadhaar: '221199887766' }
// };
// const ADMIN_DB = { /* ... Same data as before ... */
//     'vishnu123': { password: '@Vishnu89', name: 'Vishnu Reddy', dob: '02/28/2003', email: 'gowthamg78657g@gmail.com', number: '9392433367' }
// };
// const otpStore = {};
// const blockchainKeyStore = {};
// const activeVoterSessions = {};
// const activeAdminSessions = {};

// // --- Helper Functions ---
// function generateOtp(length = 6) { /* ... Same code ... */ return crypto.randomInt(10**(length-1), 10**length).toString(); }
// function generateToken(length = 32) { /* ... Same code ... */ return crypto.randomBytes(length).toString('hex'); }
// function generateVoterIdentifierHash(aadhaar) { /* ... Same code ... */
//     const ELECTION_SALT = "MY_SECRET_ELECTION_SALT_2024";
//     const hash = crypto.createHash('sha256').update(aadhaar + ELECTION_SALT).digest('hex');
//     return '0x' + hash;
// }
// function verifyAdminToken(req, res, next) { /* ... Same code ... */
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
//     if (!token) return res.status(401).json({ error: 'Unauthorized: No token provided.' });
//     const session = activeAdminSessions[token];
//     if (!session) return res.status(401).json({ error: 'Unauthorized: Invalid or expired token.' });
//     req.adminUsername = session.username;
//     next();
//  }


// // --- API Endpoints ---
// app.get('/api/ping', (req, res) => res.json({ message: 'Backend is running!' }));

// // === Voter Flow ===
// app.post('/api/voter/check-aadhaar', (req, res) => { /* ... Same code ... */
//     const { aadhaar } = req.body;
//     if (!aadhaar || !/^\d{12}$/.test(aadhaar)) return res.status(400).json({ error: 'Invalid Aadhaar format (must be 12 digits).' });
//     const voterData = VOTE_ELIGIBILITY_DB[aadhaar];
//     if (voterData) {
//         const sessionId = generateToken(16);
//         activeVoterSessions[sessionId] = { aadhaar: aadhaar, stage: 'aadhaar_verified' };
//         console.log(`[AUTH] Aadhaar ${aadhaar} verified. Session created: ${sessionId}`);
//         res.json({ success: true, sessionId: sessionId });
//     } else {
//         console.log(`[AUTH] Aadhaar ${aadhaar} not found in eligible list.`);
//         res.status(404).json({ error: 'Aadhaar number not found in eligible voter list.' });
//     }
// });
// app.post('/api/voter/request-profile-otp', (req, res) => { /* ... Same code ... */
//     const { sessionId } = req.body;
//     const session = activeVoterSessions[sessionId];
//     if (!session || session.stage !== 'aadhaar_verified') return res.status(400).json({ error: 'Invalid session or sequence.' });
//     const voterData = VOTE_ELIGIBILITY_DB[session.aadhaar];
//     if (!voterData) return res.status(500).json({ error: 'Internal error: Voter data inconsistency.' });
//     const otp = generateOtp();
//     const expiry = Date.now() + 5 * 60 * 1000;
//     otpStore[session.aadhaar] = { otp: otp, expires: expiry, type: 'voter' };
//     console.log(`[OTP] Generated Voter OTP for ${voterData.mobile}/${voterData.email}: ${otp}`);
//     console.log(`--- SIMULATED SENDING OTP ${otp} to ${voterData.mobile} and ${voterData.email} ---`);
//     session.stage = 'otp_sent';
//     res.json({ success: true, message: 'OTP sent successfully.', profile: { name: voterData.name, dob: voterData.dob, address: voterData.address, mobileMasked: '******' + voterData.mobile.slice(-4), emailMasked: voterData.email.split('@')[0].slice(0, 3) + '***@' + voterData.email.split('@')[1] } });
//  });
// app.post('/api/voter/verify-otp', (req, res) => { /* ... Same code ... */
//     const { sessionId, otp } = req.body;
//     const session = activeVoterSessions[sessionId];
//     if (!session || session.stage !== 'otp_sent') return res.status(400).json({ error: 'Invalid session or sequence.' });
//     const storedOtpData = otpStore[session.aadhaar];
//     const aadhaar = session.aadhaar;
//     if (!storedOtpData || storedOtpData.type !== 'voter') return res.status(400).json({ error: 'OTP not found or invalid type.' });
//     if (storedOtpData.expires < Date.now()) { delete otpStore[aadhaar]; return res.status(400).json({ error: 'OTP has expired. Please request again.' }); }
//     if (storedOtpData.otp !== otp) return res.status(400).json({ error: 'Invalid OTP entered.' });
//     delete otpStore[aadhaar];
//     session.stage = 'otp_verified';
//     console.log(`[OTP Verify] Voter OTP verified successfully for Aadhaar ${aadhaar}`);
//     res.json({ success: true, message: 'OTP verified.' });
//  });
// app.get('/api/parties', async (req, res) => { /* ... Same code ... */
//     if (!votingContract.methods.getAllParties) return res.status(503).json({ error: 'Blockchain service unavailable or not configured.' });
//     try {
//         const partiesRaw = await votingContract.methods.getAllParties().call({ from: backendAccount });
//         const parties = partiesRaw.map(p => ({ id: Number(p.id), name: p.name, abbreviation: p.abbreviation }));
//         res.json(parties);
//     } catch (error) {
//         console.error("[API /parties] Error fetching parties from contract:", error);
//         res.status(500).json({ error: 'Failed to fetch parties from blockchain.' });
//     }
//  });
// app.post('/api/voter/request-blockchain-key', (req, res) => { /* ... Same code ... */
//     const { sessionId } = req.body;
//     const session = activeVoterSessions[sessionId];
//     if (!session || session.stage !== 'otp_verified') return res.status(400).json({ error: 'Invalid session or sequence. OTP must be verified first.' });
//     const voterData = VOTE_ELIGIBILITY_DB[session.aadhaar];
//     if (!voterData) return res.status(500).json({ error: 'Internal error: Voter data inconsistency.' });
//     const key = generateToken(16);
//     const expiry = Date.now() + 10 * 60 * 1000;
//     blockchainKeyStore[sessionId] = { key: key, expires: expiry };
//     console.log(`[KEY] Generated Blockchain Key for Session ${sessionId}: ${key}`);
//     console.log(`--- SIMULATED SENDING KEY ${key} to ${voterData.mobile} and ${voterData.email} ---`);
//     session.stage = 'key_sent';
//     res.json({ success: true, message: 'Blockchain confirmation key sent.' });
//  });
// app.post('/api/voter/cast-vote', async (req, res) => { /* ... Same code ... */
//     const { sessionId, partyId, blockchainKey } = req.body;
//     if (!votingContract.methods.castVote) return res.status(503).json({ error: 'Blockchain service unavailable or not configured.' });
//     const session = activeVoterSessions[sessionId];
//     if (!session || (session.stage !== 'key_sent' && session.stage !== 'key_verified')) return res.status(400).json({ error: 'Invalid session or sequence. Request key first.' });
//     const storedKeyData = blockchainKeyStore[sessionId];
//     if (!storedKeyData) return res.status(400).json({ error: 'Blockchain key not found or session mismatch.' });
//     if (storedKeyData.expires < Date.now()) { delete blockchainKeyStore[sessionId]; return res.status(400).json({ error: 'Blockchain key has expired. Please request again.' }); }
//     if (storedKeyData.key !== blockchainKey) return res.status(400).json({ error: 'Invalid Blockchain Confirmation Key.' });
//     session.stage = 'key_verified';
//     const voterAadhaar = session.aadhaar;
//     const voterIdentifierHash = generateVoterIdentifierHash(voterAadhaar);
//     console.log(`[VOTE] Attempting vote for Party ${partyId} by hash ${voterIdentifierHash.substring(0,10)}... (Session: ${sessionId})`);
//     try {
//         const hasAlreadyVoted = await votingContract.methods.hasVoted(voterIdentifierHash).call({ from: backendAccount });
//         if (hasAlreadyVoted) {
//             console.log(`[VOTE REJECTED] Hash ${voterIdentifierHash.substring(0,10)}... has already voted.`);
//             delete blockchainKeyStore[sessionId]; delete activeVoterSessions[sessionId];
//             return res.status(403).json({ error: 'This voter profile has already cast a vote in this election.' });
//         }
//         console.log(`[VOTE] Submitting transaction to cast vote from backend account ${backendAccount}...`);
//         const tx = votingContract.methods.castVote(voterIdentifierHash, partyId);
//         const receipt = await tx.send({ from: backendAccount, gas: 300000 });
//         console.log(`[VOTE SUCCESS] Vote cast successfully! Tx Hash: ${receipt.transactionHash}`);
//         delete blockchainKeyStore[sessionId]; delete activeVoterSessions[sessionId];
//         res.json({ success: true, ballotId: receipt.transactionHash, message: 'Your vote has been successfully and securely recorded on the blockchain!' });
//     } catch (error) {
//         console.error("[VOTE ERROR] Blockchain transaction failed:", error.message);
//         let errorMessage = 'Failed to record vote on the blockchain. Please try again later.';
//         if (error.message.includes("revert")) { errorMessage = 'Blockchain transaction reverted.'; if (error.message.includes("already cast a vote")) { errorMessage = 'Error: Blockchain indicates this voter has already voted.'; delete blockchainKeyStore[sessionId]; delete activeVoterSessions[sessionId]; } }
//         else if (error.message.includes("gas")) { errorMessage = 'Blockchain transaction failed due to gas issues.'; }
//         res.status(500).json({ error: errorMessage });
//     }
//  });

// // === Admin Flow ===
// app.post('/api/admin/login', (req, res) => { /* ... Same code ... */
//     const { username, password } = req.body;
//     const adminData = ADMIN_DB[username];
//     if (adminData && adminData.password === password) { // !!! INSECURE PASSWORD CHECK !!!
//         console.log(`[ADMIN AUTH] Credentials verified for admin: ${username}`);
//         const otp = generateOtp();
//         const expiry = Date.now() + 5 * 60 * 1000;
//         otpStore[username] = { otp: otp, expires: expiry, type: 'admin' };
//         console.log(`[OTP] Generated Admin OTP for ${adminData.email}: ${otp}`);
//         console.log(`--- SIMULATED SENDING ADMIN OTP ${otp} to ${adminData.email} ---`);
//         res.json({ success: true, message: 'Admin credentials verified. OTP sent.' });
//     } else {
//         console.log(`[ADMIN AUTH] Invalid credentials attempt for username: ${username}`);
//         res.status(401).json({ error: 'Invalid admin username or password.' });
//     }
// });
// app.post('/api/admin/verify-otp', (req, res) => { /* ... Same code ... */
//     const { username, otp } = req.body;
//     const storedOtpData = otpStore[username];
//     if (!storedOtpData || storedOtpData.type !== 'admin') return res.status(400).json({ error: 'Admin OTP not found or invalid type.' });
//     if (storedOtpData.expires < Date.now()) { delete otpStore[username]; return res.status(400).json({ error: 'Admin OTP has expired. Please login again.' }); }
//     if (storedOtpData.otp !== otp) return res.status(400).json({ error: 'Invalid Admin OTP entered.' });
//     delete otpStore[username];
//     const adminToken = generateToken(32);
//     activeAdminSessions[adminToken] = { username: username, loggedInAt: Date.now() };
//     console.log(`[ADMIN OTP Verify] Admin ${username} successfully verified. Session token generated.`);
//     res.json({ success: true, token: adminToken, message: 'Admin login successful.' });
//  });
// app.get('/api/admin/results', verifyAdminToken, async (req, res) => { /* ... Same code ... */
//     console.log(`[ADMIN RESULTS] Request received from admin: ${req.adminUsername}`);
//     if (!votingContract.methods.getAllParties) return res.status(503).json({ error: 'Blockchain service unavailable or not configured.' });
//     try {
//         const partiesRaw = await votingContract.methods.getAllParties().call({ from: backendAccount });
//         const results = []; let totalVotes = 0;
//         for (const party of partiesRaw) {
//             const partyId = Number(party.id);
//             const voteCountBigInt = await votingContract.methods.getVoteCount(partyId).call({ from: backendAccount });
//             const voteCount = Number(voteCountBigInt);
//              results.push({ id: partyId, name: party.name, abbreviation: party.abbreviation, votes: voteCount });
//             totalVotes += voteCount;
//         }
//         console.log(`[ADMIN RESULTS] Successfully fetched results for admin: ${req.adminUsername}`);
//         res.json({ success: true, results, totalVotes });
//     } catch (error) {
//         console.error("[API /admin/results] Error fetching results from contract:", error);
//         res.status(500).json({ error: 'Failed to fetch results from blockchain.' });
//     }
// });
// app.post('/api/admin/logout', verifyAdminToken, (req, res) => { /* ... Same code ... */
//      const authHeader = req.headers['authorization']; const token = authHeader && authHeader.split(' ')[1];
//     if (token && activeAdminSessions[token]) { delete activeAdminSessions[token]; console.log(`[ADMIN LOGOUT] Admin ${req.adminUsername} logged out.`); res.json({ success: true, message: 'Admin logged out successfully.' }); }
//     else { res.status(400).json({ error: 'Invalid or missing token for logout.' }); }
// });

// // --- Server Start ---
// async function startServer() {
//     await setupBackendAccount(); // Ensure account is ready before listening
//     app.listen(port, () => {
//         console.log(`\n--- Decentralized Voting Backend ---`);
//         console.log(`Server running at http://localhost:${port}`);
//         console.log(`Connected to contract at address: ${CONTRACT_ADDRESS}`);
//     });
// }

// // --- Get Ganache accounts and set the backend account ---
// async function setupBackendAccount() {
//     try {
//         const accounts = await web3.eth.getAccounts();
//         if (!accounts || accounts.length === 0) throw new Error("No accounts found in Ganache.");
//         backendAccount = accounts[0];
//         console.log(`Backend configured to use account: ${backendAccount}`);
//         const balance = await web3.eth.getBalance(backendAccount);
//         console.log(`Backend account balance: ${web3.utils.fromWei(balance, 'ether')} ETH`);
//     } catch (error) {
//         console.error("!!! FATAL ERROR getting accounts from Ganache:", error.message);
//         process.exit(1);
//     }
// }


// /////////////////////////////////////////////////////good 

// require('dotenv').config();
// const nodemailer = require('nodemailer');
// const twilio = require('twilio');

// // Generate OTP
// function generateOTP() {
//   return crypto.randomInt(100000, 999999).toString();
// }

// // Email OTP Function
// async function sendEmailOTP(email, otp) {
//   const transporter = nodemailer.createTransport({
//     service: 'gmail', // Or another SMTP provider
//     auth: {
//       user: process.env.EMAIL_USER,
//       pass: process.env.EMAIL_PASS,
//     },
//   });

//   const mailOptions = {
//     from: `"Voting App" <${process.env.EMAIL_USER}>`,
//     to: email,
//     subject: 'Your OTP Code',
//     text: `Your OTP is: ${otp}`,
//   };

//   await transporter.sendMail(mailOptions);
// }

// // SMS OTP Function
// async function sendSMSOTP(phoneNumber, otp) {
//   const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

//   await client.messages.create({
//     body: `Your OTP is: ${otp}`,
//     from: process.env.TWILIO_PHONE_NUMBER,
//     to: phoneNumber,
//   });
// }

// // Add this endpoint
// app.post('/send-otp', async (req, res) => {
//   const { email, phoneNumber } = req.body;

//   const otp = generateOTP();
//   console.log('Generated OTP:', otp); // For debugging

//   try {
//     await sendEmailOTP(email, otp);
//     await sendSMSOTP(phoneNumber, otp);
//     res.status(200).json({ message: 'OTP sent successfully' });
//   } catch (error) {
//     console.error('OTP send failed:', error);
//     res.status(500).json({ error: 'Failed to send OTP' });
//   }
// });

// startServer(); // Call the async function to start